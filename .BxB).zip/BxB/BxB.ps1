﻿# BxB.ps1 - BxB  |  BY MICKAEL
# Dashboard (vérification virus, mises à jour, nettoyage) + Optimisations à interrupteurs
# Lance via BxB.bat (droits administrateur nécessaires)
# Chaque interrupteur est réversible. Le BIOS n'est JAMAIS modifié automatiquement.

Add-Type -AssemblyName PresentationFramework, PresentationCore, WindowsBase

# ---------- Relance en administrateur si besoin ----------
$estAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $estAdmin) {
  Start-Process powershell -Verb RunAs -ArgumentList "-NoProfile -ExecutionPolicy Bypass -STA -WindowStyle Hidden -File `"$PSCommandPath`""
  exit
}

# =====================================================================
# TRAVAIL EN ARRIERE-PLAN (Dashboard) : tourne dans un autre thread
# =====================================================================
$Work = {
  param($mode)
  $ErrorActionPreference = 'SilentlyContinue'
  $bureau = [Environment]::GetFolderPath('Desktop')
  $script:rapport = @()
  $script:fait = 0
  $script:total = 1
  $script:restaure = $false

  function Ecrire($t, $x) { $sync.Queue.Enqueue([pscustomobject]@{ T = $t; X = $x }) }
  function Titre($x) {
    $sync.Progress = [math]::Min(100, [int](100 * $script:fait / $script:total))
    $script:fait++
    $sync.Statut = $x
    Ecrire 'titre' $x
    $script:rapport += ""; $script:rapport += "=== $x ==="
  }
  function Ligne($x)  { Ecrire 'ligne' "  $x";        $script:rapport += "  $x" }
  function Alerte($x) { Ecrire 'alerte' "  [!] $x";    $script:rapport += "  [!] $x" }
  function Ok($x)     { Ecrire 'ok' "  [OK] $x";       $script:rapport += "  [OK] $x" }
  function Info($x)   { Ecrire 'info' "  $x" }
  function Demander($q, $detail = "") {
    $sync.Event.Reset() | Out-Null
    $sync.Question = @{ Texte = $q; Detail = $detail }
    $sync.Event.WaitOne() | Out-Null
    return $sync.Answer
  }
  function EspaceLibre { return (Get-PSDrive C).Free }

  function PointRestauration($nom) {
    if ($script:restaure) { return }
    Titre "Point de restauration"
    Enable-ComputerRestore -Drive "C:\" -ErrorAction SilentlyContinue
    Checkpoint-Computer -Description $nom -RestorePointType MODIFY_SETTINGS -ErrorAction SilentlyContinue
    $script:restaure = $true
    Ok "Point de restauration créé (si Windows l'a autorisé)"
  }

  function VersJournal {
    process {
      foreach ($l in ($_ | Out-String -Stream)) {
        if ($l -match '[A-Za-z0-9]' -and $l -notmatch '[\u2588\u2592\u2593]') { Info $l.TrimEnd() }
      }
    }
  }

  # ------------------------------------------------------------------
  # VÉRIFICATION APRÈS VIRUS (lecture seule)
  # ------------------------------------------------------------------
  function Verifier {
    $ErrorActionPreference = 'SilentlyContinue'
    $limite = (Get-Date).AddDays(-7)
    $script:rapport = @()

    Titre "Microsoft Defender"
    $etat = Get-MpComputerStatus
    if ($etat) {
      if ($etat.RealTimeProtectionEnabled) { Ok "Protection en temps réel active" } else { Alerte "Protection en temps réel DÉSACTIVÉE (un virus l'a peut-être coupée)" }
      Ligne "Définitions : $($etat.AntivirusSignatureVersion) ($($etat.AntivirusSignatureAge) jour(s))"
    } else {
      Alerte "Impossible de lire l'état de Defender"
    }
    $menaces = Get-MpThreatDetection
    if ($menaces) {
      foreach ($d in $menaces) {
        $m = Get-MpThreat -ThreatID $d.ThreatID
        Alerte "$($m.ThreatName) | $($d.Resources -join ', ') | $($d.InitialDetectionTime)"
      }
    } else {
      Ligne "Aucune détection enregistrée par Defender"
    }

    Titre "Programmes lancés au démarrage"
    $cles = @(
      "HKCU:\Software\Microsoft\Windows\CurrentVersion\Run",
      "HKCU:\Software\Microsoft\Windows\CurrentVersion\RunOnce",
      "HKLM:\Software\Microsoft\Windows\CurrentVersion\Run",
      "HKLM:\Software\Microsoft\Windows\CurrentVersion\RunOnce"
    )
    foreach ($c in $cles) {
      $p = Get-ItemProperty $c
      foreach ($n in ($p.PSObject.Properties | Where-Object { $_.Name -notmatch "^PS" })) {
        $v = "$($n.Value)"
        if ($v -match "AppData|Temp|Downloads|ProgramData|Public") { Alerte "$($n.Name) -> $v" } else { Ligne "$($n.Name) -> $v" }
      }
    }
    $dossiersDemarrage = @("$env:APPDATA\Microsoft\Windows\Start Menu\Programs\Startup", "C:\ProgramData\Microsoft\Windows\Start Menu\Programs\StartUp")
    foreach ($d in $dossiersDemarrage) {
      Get-ChildItem $d -Force -File | Where-Object { $_.Name -ne "desktop.ini" } | ForEach-Object { Alerte "Dossier démarrage : $($_.FullName)" }
    }

    Titre "Tâches planifiées (hors Microsoft)"
    Get-ScheduledTask | Where-Object { $_.TaskPath -notlike "\Microsoft\*" } | ForEach-Object {
      $actions = ($_.Actions | ForEach-Object { "$($_.Execute) $($_.Arguments)" }) -join " ; "
      if ($actions -match "AppData|Temp|Downloads|ProgramData|powershell|cmd") { Alerte "$($_.TaskName) -> $actions" } else { Ligne "$($_.TaskName) -> $actions" }
    }

    Titre "Services lancés depuis des dossiers inhabituels"
    $trouve = $false
    Get-CimInstance Win32_Service | Where-Object { $_.PathName -match "AppData|\\Temp\\|Downloads|ProgramData" } | ForEach-Object {
      Alerte "$($_.Name) -> $($_.PathName)"; $trouve = $true
    }
    if (-not $trouve) { Ok "Rien de suspect" }

    Titre "Programmes en cours depuis AppData, Temp ou Téléchargements"
    $trouve = $false
    Get-Process | Where-Object { $_.Path -match "\\AppData\\|\\Temp\\|\\Downloads\\" } | ForEach-Object {
      Alerte "$($_.Name) (PID $($_.Id)) -> $($_.Path)"; $trouve = $true
    }
    if (-not $trouve) { Ok "Rien de suspect" }
    Ligne "(Discord, Brave, Epic... peuvent apparaître normalement dans AppData.)"

    Titre "Programmes créés ces 7 derniers jours"
    $racines = @("$env:USERPROFILE\Downloads", "$env:LOCALAPPDATA", "$env:APPDATA", "$env:TEMP", "C:\ProgramData")
    $compte = 0
    foreach ($r in $racines) {
      Get-ChildItem $r -Recurse -Depth 3 -Force -File | Where-Object { $_.LastWriteTime -gt $limite -and $_.Extension -match "^\.(exe|dll|bat|cmd|ps1|vbs|scr|js)$" } | Select-Object -First 40 | ForEach-Object {
        Ligne "$($_.LastWriteTime.ToString('yyyy-MM-dd HH:mm')) | $($_.FullName)"; $compte++
      }
    }
    if ($compte -eq 0) { Ok "Aucun" }

    Titre "Fichier hosts (redirections de sites)"
    $hosts = Get-Content "C:\Windows\System32\drivers\etc\hosts" | Where-Object { $_ -notmatch "^\s*#" -and $_.Trim() -ne "" }
    if ($hosts) { foreach ($h in $hosts) { Alerte $h } } else { Ok "Normal (rien d'ajouté)" }

    $chemin = "$bureau\Rapport_infection.txt"
    $script:rapport | Set-Content $chemin
    Ecrire 'fin' "Rapport enregistré sur le Bureau : Rapport_infection.txt"
    Ecrire 'rapport' $chemin
  }

  function ScanHorsLigne {
    if (Demander "Lancer l'analyse Defender HORS LIGNE ?" "Le PC va redémarrer et analyser en profondeur avant le démarrage de Windows. Enregistre ton travail avant.") {
      Update-MpSignature
      Ecrire 'fin' "Redémarrage dans quelques secondes pour l'analyse hors ligne..."
      Start-Sleep -Seconds 5
      Start-MpWDOScan
    }
  }

  # ------------------------------------------------------------------
  # MISES À JOUR
  # ------------------------------------------------------------------
  function MettreAJour {
    $ErrorActionPreference = 'Continue'
    PointRestauration "Avant mises à jour et optimisation"

    Titre "Windows et pilotes (via Windows Update)"
    Info "Installe les mises à jour de Windows et les pilotes proposés par Microsoft."
    if (Demander "Lancer la recherche et l'installation des mises à jour Windows ?" "Garde le PC branché et connecté à internet. Cela peut prendre un moment.") {
      try {
        Install-PackageProvider -Name NuGet -MinimumVersion 2.8.5.201 -Force -ErrorAction Stop | Out-Null
        Install-Module -Name PSWindowsUpdate -Force -Scope AllUsers -ErrorAction Stop | Out-Null
        Import-Module PSWindowsUpdate -ErrorAction Stop
        Get-WindowsUpdate -MicrosoftUpdate -Install -AcceptAll -IgnoreReboot -ErrorAction Stop | VersJournal
        Ok "Mises à jour Windows terminées (un redémarrage peut être nécessaire)"
      } catch {
        Alerte "Échec de l'installation automatique : $($_.Exception.Message)"
        Info "Ouverture de Windows Update : clique sur Rechercher des mises à jour."
        Start-Process "ms-settings:windowsupdate"
      }
    } else {
      Info "Étape ignorée"
    }

    Titre "Applications"
    if (Get-Command winget -ErrorAction SilentlyContinue) {
      Info "Applis qui ont une mise à jour :"
      winget upgrade --accept-source-agreements 2>&1 | VersJournal
      if (Demander "Tout mettre à jour ?" "Certaines applis peuvent demander de fermer le programme.") {
        winget upgrade --all --silent --accept-package-agreements --accept-source-agreements 2>&1 | VersJournal
        Ok "Applis mises à jour"
      } else {
        Info "Étape ignorée"
      }
    } else {
      Info "winget n'est pas installé. Installe 'App Installer' depuis le Microsoft Store pour mettre à jour les applis automatiquement."
    }

    Titre "Carte mère et BIOS (relevé, rien n'est modifié)"
    $carte = Get-CimInstance Win32_BaseBoard
    $bios = Get-CimInstance Win32_BIOS
    $lignes = @()
    $lignes += "Carte mère : $($carte.Manufacturer) $($carte.Product)"
    $lignes += "BIOS : $($bios.Manufacturer) version $($bios.SMBIOSBIOSVersion) du $($bios.ReleaseDate)"
    foreach ($l in $lignes) { Info $l }
    $lignes | Set-Content "$bureau\Infos_Carte_Mere.txt"
    Ok "Infos enregistrées sur le Bureau (Infos_Carte_Mere.txt)"
    Info "Pour le BIOS, ne le fais que si tu as un vrai problème ou une version qui corrige ton souci."
    if (Demander "Ouvrir la page de recherche du BIOS de ta carte mère ?") {
      $recherche = [uri]::EscapeDataString("$($carte.Manufacturer) $($carte.Product) BIOS support")
      Start-Process "https://www.google.com/search?q=$recherche"
    }

    Titre "Carte graphique"
    $gpus = Get-CimInstance Win32_VideoController | Where-Object { $_.Name -notmatch "Virtual|Spacedesk|Basic" }
    foreach ($g in $gpus) { Info "$($g.Name) | pilote $($g.DriverVersion) | date $($g.DriverDate)" }
    if (Demander "Ouvrir la page de téléchargement du pilote de ta carte graphique ?") {
      foreach ($g in $gpus) {
        if ($g.Name -match "NVIDIA") { Start-Process "https://www.nvidia.com/Download/index.aspx" }
        elseif ($g.Name -match "AMD|Radeon") { Start-Process "https://www.amd.com/en/support/download/drivers.html" }
        elseif ($g.Name -match "Intel") { Start-Process "https://www.intel.com/content/www/us/en/download-center/home.html" }
      }
    }
    Ecrire 'fin' "Mises à jour terminées : redémarre le PC pour finir."
  }

  # ------------------------------------------------------------------
  # NETTOYAGE (les réglages sont maintenant dans l'onglet Optimisations)
  # ------------------------------------------------------------------
  function Nettoyer($ouvrirWU) {
    $ErrorActionPreference = 'SilentlyContinue'
    $libreAvant = EspaceLibre
    PointRestauration "Avant nettoyage"

    Titre "Nettoyage des fichiers temporaires"
    $dossiers = @($env:TEMP, "C:\Windows\Temp", "$env:LOCALAPPDATA\Microsoft\Windows\INetCache", "$env:LOCALAPPDATA\CrashDumps")
    foreach ($d in $dossiers) {
      if (Test-Path $d) { Get-ChildItem $d -Force -Recurse | Remove-Item -Force -Recurse }
    }
    Ok "Fichiers temporaires supprimés"

    Titre "Cache de Windows Update"
    Stop-Service wuauserv -Force
    Get-ChildItem "C:\Windows\SoftwareDistribution\Download" -Force | Remove-Item -Force -Recurse
    Start-Service wuauserv
    Ok "Cache des mises à jour vidé"

    Titre "Cache de Chrome et corbeille"
    Stop-Process -Name chrome -Force
    $chrome = "$env:LOCALAPPDATA\Google\Chrome\User Data\Default"
    foreach ($n in @("Cache", "Code Cache", "GPUCache")) {
      $p = Join-Path $chrome $n
      if (Test-Path $p) { Get-ChildItem $p -Force -Recurse | Remove-Item -Force -Recurse }
    }
    Clear-RecycleBin -Force
    Ok "Cache de Chrome vidé (mots de passe et favoris conservés)"
    Ok "Corbeille vidée"

    Titre "Programmes au démarrage"
    $run = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Run"
    $props = (Get-Item $run).Property
    if ($props) {
      $sauvegarde = "$bureau\Demarrage_sauvegarde.txt"
      foreach ($nom in $props) {
        $val = (Get-ItemProperty $run).$nom
        if (Demander "Retirer « $nom » du démarrage ?" $val) {
          "$nom = $val" | Add-Content $sauvegarde
          Remove-ItemProperty -Path $run -Name $nom
          Ok "$nom retiré du démarrage (sauvegardé sur le Bureau)"
        } else {
          Info "$nom conservé"
        }
      }
    } else {
      Info "Rien à retirer"
    }

    Titre "Optimisation du disque"
    $disque = Get-PhysicalDisk | Select-Object -First 1
    if ($disque.MediaType -eq "SSD") {
      Optimize-Volume -DriveLetter C -ReTrim
      Ok "SSD optimisé (TRIM)"
    } else {
      Info "Disque dur classique : défragmentation (peut prendre du temps)"
      Optimize-Volume -DriveLetter C -Defrag
      Ok "Disque défragmenté"
    }

    $gagne = [math]::Round(((EspaceLibre) - $libreAvant) / 1MB)
    if ($gagne -gt 0) { Ecrire 'fin' "Espace libéré : $gagne Mo" }
    Ecrire 'fin' "Nettoyage terminé."
    if ($ouvrirWU) { Start-Process "ms-settings:windowsupdate" }
  }

  try {
    switch ($mode) {
      'verif' { $script:total = 7;  Verifier; ScanHorsLigne }
      'maj'   { $script:total = 5;  MettreAJour }
      'opti'  { $script:total = 6;  Nettoyer $true }
      'tout'  {
        $script:total = 17
        Verifier        # d'abord, avant que le nettoyage n'efface des traces
        MettreAJour
        Nettoyer $false
        Ecrire 'fin' "TOUT EST TERMINÉ. Redémarre le PC pour finir les mises à jour."
        ScanHorsLigne   # en tout dernier : il redémarre le PC
      }
    }
  } catch {
    Ecrire 'alerte' "  [!] Erreur : $($_.Exception.Message)"
  } finally {
    $sync.Progress = 100
    $sync.Statut = "Terminé"
    $sync.Fini = $true
  }
}

# =====================================================================
# INTERFACE
# =====================================================================
$xaml = @'
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Title="BxB" Width="1180" Height="780"
        WindowStyle="None" AllowsTransparency="True" Background="Transparent"
        ResizeMode="CanMinimize" WindowStartupLocation="CenterScreen" FontFamily="Segoe UI, Segoe UI Emoji">
  <Window.Resources>
    <LinearGradientBrush x:Key="GradGreen" StartPoint="0,0" EndPoint="1,1"><GradientStop Color="#0FBF73" Offset="0"/><GradientStop Color="#1DF28F" Offset="1"/></LinearGradientBrush>

    <!-- Bouton -->
    <Style x:Key="Btn" TargetType="Button">
      <Setter Property="Foreground" Value="White"/>
      <Setter Property="FontSize" Value="13"/>
      <Setter Property="FontWeight" Value="SemiBold"/>
      <Setter Property="Cursor" Value="Hand"/>
      <Setter Property="BorderThickness" Value="0"/>
      <Setter Property="Template">
        <Setter.Value>
          <ControlTemplate TargetType="Button">
            <Border x:Name="b" Background="{TemplateBinding Background}" CornerRadius="10" Padding="{TemplateBinding Padding}">
              <ContentPresenter HorizontalAlignment="Center" VerticalAlignment="Center"/>
            </Border>
            <ControlTemplate.Triggers>
              <Trigger Property="IsMouseOver" Value="True"><Setter TargetName="b" Property="Opacity" Value="0.85"/></Trigger>
              <Trigger Property="IsPressed" Value="True"><Setter TargetName="b" Property="Opacity" Value="0.65"/></Trigger>
              <Trigger Property="IsEnabled" Value="False"><Setter TargetName="b" Property="Opacity" Value="0.3"/></Trigger>
            </ControlTemplate.Triggers>
          </ControlTemplate>
        </Setter.Value>
      </Setter>
    </Style>

    <!-- Interrupteur -->
    <Style x:Key="Switch" TargetType="ToggleButton">
      <Setter Property="Cursor" Value="Hand"/>
      <Setter Property="Template">
        <Setter.Value>
          <ControlTemplate TargetType="ToggleButton">
            <Border x:Name="track" Width="46" Height="26" CornerRadius="13" Background="#2B2B2B">
              <Ellipse x:Name="thumb" Width="20" Height="20" Fill="White" HorizontalAlignment="Left" Margin="3,0,0,0"/>
            </Border>
            <ControlTemplate.Triggers>
              <Trigger Property="IsChecked" Value="True">
                <Setter TargetName="track" Property="Background" Value="#18E58A"/>
                <Setter TargetName="thumb" Property="HorizontalAlignment" Value="Right"/>
                <Setter TargetName="thumb" Property="Margin" Value="0,0,3,0"/>
              </Trigger>
              <Trigger Property="IsMouseOver" Value="True"><Setter TargetName="track" Property="Opacity" Value="0.88"/></Trigger>
            </ControlTemplate.Triggers>
          </ControlTemplate>
        </Setter.Value>
      </Setter>
    </Style>

    <!-- Onglets du haut -->
    <Style x:Key="TabBtn" TargetType="RadioButton">
      <Setter Property="Foreground" Value="#8F8F8F"/>
      <Setter Property="FontWeight" Value="SemiBold"/>
      <Setter Property="FontSize" Value="13"/>
      <Setter Property="Cursor" Value="Hand"/>
      <Setter Property="Margin" Value="0,0,20,0"/>
      <Setter Property="Template">
        <Setter.Value>
          <ControlTemplate TargetType="RadioButton">
            <StackPanel>
              <ContentPresenter Margin="0,0,0,9"/>
              <Border x:Name="u" Height="3" CornerRadius="2" Background="Transparent"/>
            </StackPanel>
            <ControlTemplate.Triggers>
              <Trigger Property="IsChecked" Value="True">
                <Setter Property="Foreground" Value="White"/>
                <Setter TargetName="u" Property="Background" Value="#18E58A"/>
              </Trigger>
              <Trigger Property="IsMouseOver" Value="True"><Setter Property="Foreground" Value="White"/></Trigger>
            </ControlTemplate.Triggers>
          </ControlTemplate>
        </Setter.Value>
      </Setter>
    </Style>

    <!-- Menu de gauche -->
    <Style x:Key="NavBtn" TargetType="RadioButton">
      <Setter Property="Foreground" Value="#B5B5B5"/>
      <Setter Property="FontWeight" Value="Bold"/>
      <Setter Property="FontSize" Value="14"/>
      <Setter Property="Cursor" Value="Hand"/>
      <Setter Property="Margin" Value="0,0,0,8"/>
      <Setter Property="Template">
        <Setter.Value>
          <ControlTemplate TargetType="RadioButton">
            <Border x:Name="n" CornerRadius="12" BorderThickness="1" BorderBrush="Transparent" Background="Transparent" Padding="16,13">
              <ContentPresenter VerticalAlignment="Center"/>
            </Border>
            <ControlTemplate.Triggers>
              <Trigger Property="IsMouseOver" Value="True"><Setter TargetName="n" Property="Background" Value="#141414"/></Trigger>
              <Trigger Property="IsChecked" Value="True">
                <Setter Property="Foreground" Value="White"/>
                <Setter TargetName="n" Property="BorderBrush" Value="#18E58A"/>
                <Setter TargetName="n" Property="Background" Value="#0F0F0F"/>
              </Trigger>
            </ControlTemplate.Triggers>
          </ControlTemplate>
        </Setter.Value>
      </Setter>
    </Style>

    <!-- Barre de progression -->
    <Style TargetType="ProgressBar">
      <Setter Property="Height" Value="8"/>
      <Setter Property="Template">
        <Setter.Value>
          <ControlTemplate TargetType="ProgressBar">
            <Grid>
              <Border Background="#1B1B1B" CornerRadius="4"/>
              <Border x:Name="PART_Track"/>
              <Border x:Name="PART_Indicator" HorizontalAlignment="Left" CornerRadius="4" Background="{StaticResource GradGreen}"/>
            </Grid>
          </ControlTemplate>
        </Setter.Value>
      </Setter>
    </Style>

    <!-- Barre de défilement fine -->
    <Style TargetType="ScrollBar">
      <Setter Property="Width" Value="8"/>
      <Setter Property="Background" Value="Transparent"/>
      <Setter Property="Template">
        <Setter.Value>
          <ControlTemplate TargetType="ScrollBar">
            <Grid Background="Transparent">
              <Track x:Name="PART_Track" IsDirectionReversed="True">
                <Track.Thumb>
                  <Thumb>
                    <Thumb.Template>
                      <ControlTemplate TargetType="Thumb"><Border Background="#2E2E2E" CornerRadius="4" Margin="1"/></ControlTemplate>
                    </Thumb.Template>
                  </Thumb>
                </Track.Thumb>
              </Track>
            </Grid>
          </ControlTemplate>
        </Setter.Value>
      </Setter>
    </Style>
  </Window.Resources>

  <Border CornerRadius="16" Background="#070707" BorderBrush="#1A1A1A" BorderThickness="1">
    <Grid>
      <Grid.ColumnDefinitions>
        <ColumnDefinition Width="250"/>
        <ColumnDefinition Width="*"/>
      </Grid.ColumnDefinitions>

      <!-- ===== Menu de gauche ===== -->
      <Border Grid.Column="0" Background="#0B0B0B" CornerRadius="16,0,0,16" BorderBrush="#161616" BorderThickness="0,0,1,0">
        <StackPanel Margin="18,24,18,18">
          <StackPanel Orientation="Horizontal" Margin="4,0,0,30">
            <Image x:Name="Logo" Width="48" Height="48" RenderOptions.BitmapScalingMode="HighQuality"/>
            <StackPanel Margin="12,0,0,0" VerticalAlignment="Center">
              <TextBlock Text="BxB" FontSize="24" FontWeight="Black" Foreground="White"/>
              <TextBlock x:Name="SousTitre" FontSize="11" Foreground="#6E6E6E" Margin="0,2,0,0"/>
            </StackPanel>
          </StackPanel>
          <RadioButton x:Name="NavDash" GroupName="nav" IsChecked="True" Style="{StaticResource NavBtn}" Content="🏠   DASHBOARD"/>
          <RadioButton x:Name="NavOpti" GroupName="nav" Style="{StaticResource NavBtn}" Content="🚀   OPTIMISATIONS"/>
        </StackPanel>
      </Border>

      <!-- ===== Contenu ===== -->
      <Grid Grid.Column="1">
        <Grid.RowDefinitions>
          <RowDefinition Height="Auto"/>
          <RowDefinition Height="*"/>
          <RowDefinition Height="Auto"/>
        </Grid.RowDefinitions>

        <!-- Barre de titre -->
        <Grid x:Name="TitleBar" Grid.Row="0" Background="Transparent" Height="56">
          <StackPanel Orientation="Horizontal" HorizontalAlignment="Right" VerticalAlignment="Top" Margin="0,14,16,0">
            <Button x:Name="BtnMin" Content="—" Width="36" Height="30" Margin="0,0,6,0" Background="#161616" Style="{StaticResource Btn}"/>
            <Button x:Name="BtnClose" Content="✕" Width="36" Height="30" Background="#161616" Style="{StaticResource Btn}"/>
          </StackPanel>
        </Grid>

        <Grid Grid.Row="1">
          <!-- ===== PAGE DASHBOARD ===== -->
          <Grid x:Name="PageDash">
            <Grid.RowDefinitions>
              <RowDefinition Height="Auto"/><RowDefinition Height="Auto"/><RowDefinition Height="*"/>
            </Grid.RowDefinitions>

            <Grid Grid.Row="0" Margin="20,0,20,0">
              <Grid.ColumnDefinitions><ColumnDefinition Width="*"/><ColumnDefinition Width="*"/><ColumnDefinition Width="*"/></Grid.ColumnDefinitions>

              <Border Grid.Column="0" Margin="6" Padding="20" CornerRadius="14" Background="#0F0F0F" BorderBrush="#1C1C1C" BorderThickness="1">
                <StackPanel>
                  <Border Width="48" Height="48" CornerRadius="13" HorizontalAlignment="Left" Background="{StaticResource GradGreen}">
                    <TextBlock Text="🛡️" FontSize="24" HorizontalAlignment="Center" VerticalAlignment="Center"/>
                  </Border>
                  <TextBlock Text="Vérifier une infection" FontSize="16" FontWeight="Bold" Foreground="White" Margin="0,14,0,0"/>
                  <TextBlock Text="Lecture seule : Defender, démarrage, tâches, services et fichiers récents. Rien n'est supprimé." FontSize="12" Foreground="#8A8A8A" TextWrapping="Wrap" Margin="0,6,0,14" MinHeight="64"/>
                  <Button x:Name="BtnVerif" Content="Lancer la vérification" Height="38" Foreground="#04130B" Background="{StaticResource GradGreen}" Style="{StaticResource Btn}"/>
                </StackPanel>
              </Border>

              <Border Grid.Column="1" Margin="6" Padding="20" CornerRadius="14" Background="#0F0F0F" BorderBrush="#1C1C1C" BorderThickness="1">
                <StackPanel>
                  <Border Width="48" Height="48" CornerRadius="13" HorizontalAlignment="Left" Background="{StaticResource GradGreen}">
                    <TextBlock Text="🔄" FontSize="24" HorizontalAlignment="Center" VerticalAlignment="Center"/>
                  </Border>
                  <TextBlock Text="Tout mettre à jour" FontSize="16" FontWeight="Bold" Foreground="White" Margin="0,14,0,0"/>
                  <TextBlock Text="Windows, pilotes, applications (winget), plus un relevé de la carte mère, du BIOS et de la carte graphique." FontSize="12" Foreground="#8A8A8A" TextWrapping="Wrap" Margin="0,6,0,14" MinHeight="64"/>
                  <Button x:Name="BtnMaj" Content="Lancer les mises à jour" Height="38" Foreground="#04130B" Background="{StaticResource GradGreen}" Style="{StaticResource Btn}"/>
                </StackPanel>
              </Border>

              <Border Grid.Column="2" Margin="6" Padding="20" CornerRadius="14" Background="#0F0F0F" BorderBrush="#1C1C1C" BorderThickness="1">
                <StackPanel>
                  <Border Width="48" Height="48" CornerRadius="13" HorizontalAlignment="Left" Background="{StaticResource GradGreen}">
                    <TextBlock Text="🧹" FontSize="24" HorizontalAlignment="Center" VerticalAlignment="Center"/>
                  </Border>
                  <TextBlock Text="Nettoyer le PC" FontSize="16" FontWeight="Bold" Foreground="White" Margin="0,14,0,0"/>
                  <TextBlock Text="Fichiers temporaires, caches, corbeille, programmes au démarrage et optimisation du disque." FontSize="12" Foreground="#8A8A8A" TextWrapping="Wrap" Margin="0,6,0,14" MinHeight="64"/>
                  <Button x:Name="BtnOpti" Content="Lancer le nettoyage" Height="38" Foreground="#04130B" Background="{StaticResource GradGreen}" Style="{StaticResource Btn}"/>
                </StackPanel>
              </Border>
            </Grid>

            <Grid Grid.Row="1" Margin="26,12,26,0">
              <Grid.ColumnDefinitions><ColumnDefinition Width="Auto"/><ColumnDefinition Width="*"/></Grid.ColumnDefinitions>
              <Button x:Name="BtnAll" Grid.Column="0" Content="⚡   TOUT FAIRE" Width="240" Height="52" FontSize="16" Foreground="#04130B" Background="{StaticResource GradGreen}" Style="{StaticResource Btn}"/>
              <StackPanel Grid.Column="1" Margin="22,0,0,0" VerticalAlignment="Center">
                <TextBlock x:Name="Statut" Text="Prêt" FontSize="13" Foreground="#CFCFCF" Margin="0,0,0,8"/>
                <ProgressBar x:Name="Prog" Minimum="0" Maximum="100" Value="0"/>
              </StackPanel>
            </Grid>

            <Grid Grid.Row="2" Margin="26,16,26,8">
              <Grid.RowDefinitions><RowDefinition Height="Auto"/><RowDefinition Height="*"/></Grid.RowDefinitions>
              <Grid Grid.Row="0" Margin="0,0,0,8">
                <TextBlock Text="JOURNAL" FontSize="12" FontWeight="Bold" Foreground="#6E6E6E" VerticalAlignment="Center"/>
                <Button x:Name="BtnRapport" Content="📄  Ouvrir le rapport" Visibility="Collapsed" HorizontalAlignment="Right" Padding="14,6" Background="#161616" Style="{StaticResource Btn}"/>
              </Grid>
              <Border Grid.Row="1" CornerRadius="12" Background="#050505" BorderBrush="#1A1A1A" BorderThickness="1">
                <RichTextBox x:Name="Log" IsReadOnly="True" Background="Transparent" BorderThickness="0" Padding="12" FontFamily="Consolas" FontSize="12.5" Foreground="#CFCFCF" VerticalScrollBarVisibility="Auto"/>
              </Border>
            </Grid>
          </Grid>

          <!-- ===== PAGE OPTIMISATIONS ===== -->
          <Grid x:Name="PageOpti" Visibility="Collapsed">
            <Grid.RowDefinitions><RowDefinition Height="Auto"/><RowDefinition Height="*"/></Grid.RowDefinitions>
            <Grid Grid.Row="0" Margin="26,0,26,0">
              <StackPanel Orientation="Horizontal" VerticalAlignment="Bottom">
                <RadioButton x:Name="TabPriv" GroupName="tabs" Tag="priv" IsChecked="True" Style="{StaticResource TabBtn}" Content="CONFIDENTIALITÉ"/>
                <RadioButton x:Name="TabConfort" GroupName="tabs" Tag="confort" Style="{StaticResource TabBtn}" Content="CONFORT"/>
                <RadioButton x:Name="TabReseau" GroupName="tabs" Tag="reseau" Style="{StaticResource TabBtn}" Content="RÉSEAU"/>
                <RadioButton x:Name="TabPerf" GroupName="tabs" Tag="perf" Style="{StaticResource TabBtn}" Content="PERFORMANCES"/>
                <RadioButton x:Name="TabJeux" GroupName="tabs" Tag="jeux" Style="{StaticResource TabBtn}" Content="JEUX"/>
              </StackPanel>
              <StackPanel Orientation="Horizontal" HorizontalAlignment="Right" VerticalAlignment="Center" Margin="0,0,0,8">
                <Button x:Name="BtnRestore" Content="↩  Tout restaurer" Padding="16,9" Margin="0,0,10,0" Background="#161616" Style="{StaticResource Btn}"/>
                <Button x:Name="BtnBoost" Content="⚡  BOOST" Padding="22,9" Foreground="#04130B" Background="#18E58A" Style="{StaticResource Btn}"/>
              </StackPanel>
            </Grid>
            <ScrollViewer x:Name="Scroll" Grid.Row="1" Margin="20,12,12,6" VerticalScrollBarVisibility="Auto" HorizontalScrollBarVisibility="Disabled">
              <UniformGrid x:Name="Cartes" Columns="3"/>
            </ScrollViewer>
          </Grid>
        </Grid>

        <!-- Pied de page -->
        <Grid Grid.Row="2" Margin="26,0,26,16">
          <TextBlock x:Name="Toast" FontSize="12" Foreground="#7E7E7E" VerticalAlignment="Center" Text="⚡ = réglage recommandé"/>
          <TextBlock Text="BY MICKAEL" FontSize="15" FontWeight="Black" Foreground="#18E58A" HorizontalAlignment="Right" VerticalAlignment="Center">
            <TextBlock.Effect><DropShadowEffect Color="#18E58A" BlurRadius="14" ShadowDepth="0" Opacity="0.75"/></TextBlock.Effect>
          </TextBlock>
        </Grid>
      </Grid>

      <!-- ===== Fenêtre de question ===== -->
      <Border x:Name="Overlay" Grid.ColumnSpan="2" Background="#E6030303" CornerRadius="16" Visibility="Collapsed">
        <Border Width="540" VerticalAlignment="Center" HorizontalAlignment="Center" Padding="28" CornerRadius="18" Background="#0F0F0F" BorderBrush="#1F3D2E" BorderThickness="1">
          <StackPanel>
            <TextBlock Text="❓" FontSize="30"/>
            <TextBlock x:Name="QTexte" FontSize="17" FontWeight="Bold" Foreground="White" TextWrapping="Wrap" Margin="0,10,0,0"/>
            <TextBlock x:Name="QDetail" FontFamily="Consolas" FontSize="12" Foreground="#8A8A8A" TextWrapping="Wrap" Margin="0,10,0,0"/>
            <StackPanel Orientation="Horizontal" HorizontalAlignment="Right" Margin="0,24,0,0">
              <Button x:Name="BtnNon" Content="Non" Width="110" Height="40" Margin="0,0,10,0" Background="#1E1E1E" Style="{StaticResource Btn}"/>
              <Button x:Name="BtnOui" Content="Oui" Width="110" Height="40" Foreground="#04130B" Background="{StaticResource GradGreen}" Style="{StaticResource Btn}"/>
            </StackPanel>
          </StackPanel>
        </Border>
      </Border>
    </Grid>
  </Border>
</Window>
'@

# Modèle d'une carte à interrupteur
$carteXaml = @'
<Border xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Margin="6" Padding="20" CornerRadius="14" Background="#0F0F0F" BorderBrush="#1C1C1C" BorderThickness="1" MinHeight="170">
  <Grid>
    <Grid.RowDefinitions><RowDefinition Height="Auto"/><RowDefinition Height="*"/></Grid.RowDefinitions>
    <Grid.ColumnDefinitions><ColumnDefinition Width="*"/><ColumnDefinition Width="Auto"/></Grid.ColumnDefinitions>
    <TextBlock x:Name="CTitre" FontSize="16" FontWeight="Bold" Foreground="White" TextWrapping="Wrap" Margin="0,0,12,0"/>
    <ToggleButton x:Name="CTog" Grid.Column="1" VerticalAlignment="Top"/>
    <Button x:Name="CBtn" Grid.Column="1" Content="Ouvrir" Visibility="Collapsed" Padding="16,7" VerticalAlignment="Top" Background="#1E1E1E"/>
    <StackPanel Grid.Row="1" Grid.ColumnSpan="2" Margin="0,16,0,0">
      <TextBlock x:Name="CD1" FontSize="12.5" Foreground="#B0B0B0" TextWrapping="Wrap"/>
      <TextBlock x:Name="CD2" FontSize="12.5" Foreground="#7A7A7A" TextWrapping="Wrap" Margin="0,8,0,0"/>
    </StackPanel>
    <TextBlock x:Name="CReco" Grid.Row="1" Grid.ColumnSpan="2" Text="⚡" FontSize="14" Foreground="#18E58A" HorizontalAlignment="Right" VerticalAlignment="Bottom" Visibility="Collapsed"/>
  </Grid>
</Border>
'@

try {
  $window = [Windows.Markup.XamlReader]::Load((New-Object System.Xml.XmlNodeReader ([xml]$xaml)))
  foreach ($n in 'TitleBar','SousTitre','Logo','BtnMin','BtnClose','BtnVerif','BtnMaj','BtnOpti','BtnAll','Statut','Prog','Log','BtnRapport','Overlay','QTexte','QDetail','BtnOui','BtnNon','NavDash','NavOpti','PageDash','PageOpti','TabPriv','TabConfort','TabReseau','TabPerf','TabJeux','BtnBoost','BtnRestore','Cartes','Scroll','Toast') {
    Set-Variable -Name $n -Value $window.FindName($n)
  }

  # ---------- Logo BxB (intégré dans le script) ----------
  $logoB64 = 'iVBORw0KGgoAAAANSUhEUgAAAIAAAACACAYAAADDPmHLAAA1tklEQVR4nO29eZgkVZX3/7n3RkQutVdv0DTQDbIjoALu0iCI4LAqqD9nfEfHBR0VUXEcB2QHNxxFBdFRUEbQZl4H1xEVqkEUBJtuWWSnF3pfaq9cIuLe+/sjIjIjMyOrqpvGAd46zxMVUZEZEfec873fc+4SNwX/C2KtFf8bz32+ixDC/m+XYafLBRdcIK21ylrrxPsZ57cX0WQr+Zw/8Lm4qbVWLl2KXLr0QnPRRReZjM/VmjUj3T09z8XTX1gyMgI9PdDT0zMuhAiaP48rjAKMEKLFls9WdioAliyx6owzQAihk3Nbt25dUKmYw4BXaK0PArEQbJ+19AsxwwbGgJTSCmGHQQxba1cLIR51HGdZsegs7+3tfTr5bswIIm3fZys7xQFxwWwSwzZtGn5JGIZ/p7U+RQhxeFdXZ2ehkEcpkXwfePGFu2cnkW2EEBgDlUqVkZGRqhBiuRDy50rJn++yS/+DybeXLFmizjzzzGcNhGcFgJieZILIDRu2HGMMH7DWnjJrVn/ecSTWaqSUWimZeFykthmpi03trTFGaG2UEAqtLdu2DWpruRW4dsGCOT+DKJQShYYdrk3Ojl64ZMkSFTteb9iw9Uhrudh1veO7ujqwVpPLqRAQ4EiiGDYjk0tDhZBSIqW0gHEcYWfN6nGEUCeWSpUT163bcg+IC4QQv4EICDszLEwpAwMDDsDjjz/evXbtlqs2bNimK5XQVqu+ttaG1lpjZ2Rni7HWhr4fhOVyYLdsGbXr12/9z1WrVu2a9sn2ynbT8MDAgHP00UeHq1ate63n5b/b19e7n7WBLRRyhpma/rcSU6n4COHIwcHhDUEQfGjPPXf5qd2BkDBtANhUvF+zZtM/e5771e7uTieXU6GUcodDyYw8KwnLZd8plaqUy+VLd9993vm2KSGfSqbluLTzV69e/8Xe3p5zpbS2UHDNdO8xI8+JOIWCZ4TAFgqF89as2binEOLdF1xgpbV2p/UsioEB6wCsWrXhyomJwFYq1cDOxPnnlfh+4JfL2q5evfEmIQRLluykXtfE+StXrvvixERgfT/w7Yzzn5cSBGEMgg0/jHw34PBsmttJZrly5doPj45WbLXqzzj/eS6+H/ilUmhXrlz7+XQF3m5ZsmSJipz/zKs2bhwMy+XqTPPuhSGmUvGDoaGSXbly/elQ6zDKlEx6sFHsEJs3by5Wq3bF7Nn9e8cJ33M+OjUjO0VMuewzODgyms/Lg2fNmrWeaAyhZTCpnUOlEMJMTARXzJ07Z++4V2/G+S8ckYWCZ2fPntU7Olq9Rghhb745u7K3xIclS6JuxVWrNr88l1P/LITWUrozHTwvPFFKmbC/v++k1as3nLTnnuLnNqPLuKVWn3FGNChhTPClvr4e4XkuzAzcvCDFcRyZz7vWGPMla60HGJrHHNL/xAgx69Ztfn13d9cxSlnNTPfuC1mkUpg5c+bs98wzm84QQtiBgcaEsAEAN98c7X0/+Fh3d5d1HGdm0P4FLo7j4LrKhmH4MSEES5de2JAI1ujAWiuFEGbDhqGFQeA/Nm9enztD/y8OCYLQDA9PSN+vvGbBgl3uTucCaQaQAJVK6dQ5c2Z7nudqZpz/ohDXdUxvbw9BYN4OsHRp3a/pVkBCDac5joAZ57+YRAphsNb8nbX2U0KIsPYBRB0/QgizefP4rkLII6w1tc9m5EUh0lpjC4XC3qtXbzkEavM4a06WAOXy8OF9fT0FpcQM/b/IxHUd3dvbg9bBawCWLl0qoR4CBIAx4hWFQh4pd8Y48s5sQDyfsfjC0dN1FULwivS5BACJFgdIuSOFSBnBPhctx9SE4obi/S2BYZsOnys9m3WEnaSnEAKkZD+AxYsXa6gDwABYa/eO/59G/I8N0OJw2+aYKQwnGnYt5zNvaUGI7O/tFJkM2M9Cz8yiJicttMzj2Cl6SmMs1oo9rLV5IUQFEA7RKJG11qqVK9f3WWuneIjNUDD1okfNUBkG2q5K01yGBCBpQ4jG5+00MGSBO/WcTB2Tz6Z5+0wmS+1F0//psoiWg2mKRQi6N27c2A1UrLU4Npo7xsjISLdSoi8uXcadsxycPjeZgbIAkP4nSxGRcSxoMZZIvWeSPPdZGCjaZYC7We+GStBOz2Y0TKZnk/Ntck6kdGy67XbraRFCdmmt+oDNxAwwrQtbjFJzukkZI30+y3DNGqRFpD5qU9tbXipK/Z82Ugu2pmOgLKc26ZMG+k7Xs41ezedbAC9ATMXaqac3fW0aAMhCf7I3TedM036q0NBSvMaS2gzFrQAh6+dshrFawGCbNK9VsaayZeiYpW+L3s0g2EE9RZx6WZnSQbbql6XjtIHeKFMAoMn5Lc41kTGsqR9nGSorbGRKs8OTc81Ol6l9YqAMQ7VjhcwyNDs7raMFq1M6pWyQCYZ2z2inZ3N5Y/0adJNNuqevkfVnN4eLKWQSADQ7P8O5VsfG0K1AaDZUi4HaGKaG5CajiJQRiB0vZAoEsv49mwZE2tDQapwskLcBd8OxbnJ++php6JkFgrReaZ3TuqqUrgkgkmH+OCxsBxu0B0Bb56cNoFPHYRtQxMacLgCgqVakHNtgEJX6X2UAwtbv0ZJoZemaBmra2WkdJwN9mh3ZDj1TdN/s8MTZQqX0Td7AS75LHfCJ47cDBNPLAVpqflgHgEmOw8bzmQZqV0NEatdEbQ01vtnpKcOkj20aDG2SKdJlaApvNSebJn00LWDPAkFbFhCNjkl0a3F+WicnPnZSOtr4+6rxvun8aJogaAVAw/cTgySOS5RPHB+CDerHtXNpICS1pilhavfgltrfXCMUSNV6nN7SrJAYxWaFgbSj0rU4Xfa0vin9m3VsyIEmY4FEN2hwfgsAnPpeKhC6fowT6Z7YUqiY8GRUhlruMLW0AiCTsptqg0kcnzjfj4+D+vlMA2Vly2nbNDlfiEhR0VTjTWwc6YB1Gg0mY2A0hIU0m2RIS4jTTbqmAZ4CfAMbNIGgZst2OlJ3VGatjzfpgHVB6ggEODEDWJAxgBN/JyCoPT95VHswTJ4ENlB/YhCdcn4Axo+3atM+AwSTMkCqoC21QdUdnhhFuBEQpNNoMJvFBk2Zc0sISFF/A+2nnN6gcxbQs8JdO0mHuGY9U/pJN3K+SPZe9CxpiRI/N1LF2EYQ1Gw4dSiYIglsSorSsb7m/AroKuhyfFwGXckAQXNzKcv3zQyQdr5bN4r06nvjxJ/Fe5umz3TOkM4HGhSNnd9U+01KT5sGezXStwXo28MACQia8plmHVUu1tUD60UsgBfdX5qIqJOVdxqahbFOSQeRtbRjvzYAaGq2WQNk1IrEGHoCwhKE49GxrqQMlDJOc69ho/fr+1rtSAyjUobJRZvK1Y9l/FkDI6QTqBQI2jYDs6g/FeJ0NQJ4WAFdivWLdWwIA82tnTZ6imagJ+yWOD8POh/tVR5kHlSKSa2NF48DZMJuTY+qhYTtDgE2Vf6Mpl+a/nUZwgkIRiEcBX8EqhshGEvVjKwmYEaGXDMORA5z6jVBFUEVUo7Pg1OIDZOqKSYNgPTW1ORqcL5t1K8G9KT2+xGowxLo8QgA/jD42yJgNFB/WrdJkt0EBEmGL3ORfk6sp0ycXwSnA1TMpCrFpABKRIdGREBAx3lPwgCW7QBAOoikWMDEADBxzTAhaB/CKgRl8McjAJQ3wPDDEAxH35ni4VNKOgxID5xO8PrA642NUohAoApxLUnYIA2CdPNR0BIGarU/K8yFsfOrkdOD8YjlSmthfFXEAPbZTp5KsYB0Ise73ZCbFenqVMDxwQ3A0eDE1O9Qp30rQMYsJ0XkJ9kcCiALkNkMYFLOTyjHxAmg1qBDCAMIquCXoToB5SHY+hBUtoEOsNLF7vA7JdHzhakiTBD9Lx1wxkBui4BQ3CUyUmIgx49rjBeHi3QISLUIskJAmgFMiuVsDHRdiVluAkobYOTJGBg+VhWYegh9Ej2tRpgKwsaLqikPnFGQmyHXDx0LIBeAG4JnwLXgxE5XcV+HSnpCExAk4UhEzrdJ0tgqGc3AtF1SIDDJFoMgDCHwwa9AtQIjG2BsJALHHm9CHPiPiGJ3fLPtNY4FHUSgGn0GvfUR2PIX5MgTCD0MXgClcSiMQMd8cH1wqjEb5OpJYS1/yGKBpFxNSa5J5TlJqAvLEf37YzC8AaphxEiHnYuY/0qEs4PrMFgDQQkmtmKHn0ZveRC59QHk2Lqo3BUfxkege2GkZ2ghJ8CLHe/Ge1Rq00RAMDErWNIRr1kyGCCd/adCQLLVGCCEIATfh2oVJkahEoLTBS/7NCXRxTMrVyKVs92zxATgeh7dPS+hf4+DUXucEH2w7WH0wzehVt8GQkNlE5Sq0L0gpki/DgCZCgGyuRcx3SeQ6JmEtzQAwgiIuhKBoDoWOaVUxi46HrHXaWzcMsjIyChSyu3U0yKlJF/opq9/ER1zjsDZ5+2AwTz1P4i/3oTY9gjkgPIT0BtC9x6gJRgFNu4DcR3qHUOpPpB0s7s2VjDdEFDLMVIgSICgDYQ63kLwA6j6UNFQMeh8HpXr5r47fs/ixW+gs7MLY7Lpp50IoleaOjo62HXXXXjZYYfxlpNO4i0nn4r7hkvRa05A/eHzUNoaJZ2BgM55oCpxwug21f6M9raME8Maw6WcbsOMfKcCfgmqNtLTduFYwwX/di7f/s736O7uIQzDKXVLixQCz/Po6elh0aI9ee1rX8dpbz2Dlx32Ftj7LZh7r0Y+8H1w8rB5JWgPuuOOIesCbuzCdF+IjhwuYr2EyM5FY5m6GVhzvo2cr1MgCELwNfgh+BZ8UU84pIzu1KbZP5lYwA9CytsG2bBxE8vuv5//+N73OPSQQ7jkkks46eST0d1Xo35xNoxtjEEgId9dr/0158fZf8ICDZ9FZazFfR0nfSadC8T5gPYhqEQA8CWEcZer3VE9BdpaSuUKo2PjrFy1itsHlvLFL32Z0089hS986cvsfuSH0cVdUXd+IfLU5lUgOoloIQ8iD3ggwtjxifM1tTGDpCKb7MJN0hGUbPHFxtT32kYGCAwEGnxTB0BqVrEQEiFENB11O0UIgZQSz/NierU8+NBfOfmUU7jskov57Hnno4+7AnXzWXFZRmGiEjet0v3tTWMMyo2Akuusf2YN+BNQHokov6F5mG4Nxa/W+xLCxrLuiJ4iBqBSikKhgBACrTU3/fjH3HnXH7jl/97M4a88DTOyGXnPf0BOwbb1UZgV+XpzUYbxlgJBkgjWegKzJTsJTDu/BgJiFkgxQWggsNHmA1VBYwtrO6t+uhjxtdbaWgjp6OgA4N/O/xxz587lfR/4IPrQd6Hu/BbkilGmXlOijbgeyEEo9kG+KzpXHYeJwYjuQz+jKqf0kg6UgygWP0s909dprWvHPT19rN+wgVNOeyv33PNHFrzqnzCP3oXc+hTYQSiOgewE5YMMoj4CqSOnS1OvrLKJxTPKOcWEEBpbA8bWQRCmtgQAvpj2agLtakxy3hjTkjtoraPEKV/kXz7zb5x40snMP/LtmHt+gih0o6XTvuvBgsCihteDDaA6CIUwovHScEz5FtO3EFMbW69fmxwI6aDEZihXp6WnlDLzfKKn1roFQEEQ0NPdw/oN6/nsv36WG374Q8xhb4OfXQrWh5GhuAmc6h9QcetMGlDNjm9fvjatgPS/qdpfYwCircH5RAygpkODgiAI8H2/9Xnx/0q5FAqFFhAYY8jlcgwObeOHP7yRcz/1Scy7voYz/yU402iK2cf+iLjpvLjsMWNYAaHBvu185CHHTf1SRHUCNjwZHcvJEV8qlWIdsvUsFDpqIS4tQeBTKHRwy09/xspn1rLo4GMwv7oaWarA6Dh0+1FzOAjB1XVWVqbuq4QFJhmAa9MKSNf+eEt150cgiIEQxlsCgimmmCilKJXGectbTuITn/g42liU4wIWC5QnJnj4gQe4/gc38Ne/PkxHR2cmCIQQLB0Y4NxPfRI5fx82bNzIL3/5S4qFYsv3hZT4fpUD9tufV736NZjF70P+9KvQ2RcpNzGGOfJk5CHH8eCDD7Js2TI8L9d4n1Qr6owzz8BZeOikegohqFQq/Pu/X8mhhx6KQSBlNIZvLWzdspmlt9/O939wA0EQ4DhOAwisBdd1GR0d5g933sGid70L0zkfue4xyPtQCSAXQl5HeZgb1/wkT8vyYYZMPhrYfJMGEBA7P2EBETGAM3ktTGhv990XcNRRRyUPI825J7z5eN7/wQ9y4okncu+995LPNzJB9C6DYu3adRitEUrRUezg6m9czfIV97d9dndXD/cvu4+9j3on5qE/IR/7M+SLWK8fjn8fpdIEZ7z1bTz2xONt7/He9/4T/9+73kU4OoTq7ptCz5BXv/rVHHHEEbHRGrnlbW89nVNPO41TTz21BuosWfnUU5GN8rOgYqImdzWMk/BUPuY01f70ZB7IBEEdACPUv5TOnhtAYOvOr4UBAQFRW9wX4E4vE/YrZbTWhD/6Ks7dv4SOnjhrhfDQ19Pz95/i/PPO44QTT2ybK/i+jwacbRvp7p/LT/77/3L44UfgV32kUg2JpOM4DA0P8sGzPsRvfvdb7Bmfwn7xQ4itGzFvPwfVN4+vXXY5jz3xOP39swmCoPZcKSXlcpn99t2Hq6++GjG0EbH0Fjj9rCnbfuOlClpr9OfehSqPg+NExvQK6NPO4thj38gpJ53EjT+6ia6unoZkMJFKuRL5w7pQiSuab+sJeBj7IgnRhowKnF3OOiR7UmebaaOh9jcngkQASEJAy+9eZYsQAqUUqhKgRkuosXK0HxnD/c1PsGODLNpvf4r5QqZRjNF0Fgu4SiHu/z3hf32HhQsX8vnLL2dsfBRrLWEYEoYhWmuq1SrdXT3cdvttXPmlL6Hm7Y4+4T2YWYuQx57JmtWr+dKVV1LIF6lWqxE44+ujLeCqr32VXM7D/ODfEevWxLaZvJNLShnpOV5GjZWibbyCWvkU8tab0Vpz4EEH1mySJb29vdHBeDmqaIGIKl7CwOmQXGMA6o6fBKNT5jtYkQoBItp0ah8Ss0DMAH7S7p7yzpFMVGDbOAxNYIdL2MEJ9Kw9MV6B0tgofhi0GEbGfdz77rMPWIveug3nx99Fr36K933g/Zx26mmMjg7jOI0RTmtNsdjJBRdexPLly3GOPR19zpcRjst553+OoaFBXM9riMWO4zA+PsrHPvIRjjr6aMJld6Fu/zXke6enX1L04RIMTUR6Dk5gy6B32w+lFMNDw5mXJuU46JBDoltt2gKhA9qJmqFJzQ9to+NNU+2HtiBoDQENJcjY0jmAFtgwRqMvoCqxnkxdPJlhou+JY0+Dlx4JroewBrwc7sEvh1yBH/7gB4RhQLFYJAzTLCCw1nLq6aeDENhHH8VWBeLaK7EXf41vfuPr3HPPnxgcGsR1vVr+YK1FKcXERJn3v/+D3Pn7Oyjstid33nknN954I52d3Q3duVJKSqUJDtj/AC655BLM6DDye9/A2nykc1yWSZSsMYR4/2dqw7TCWuifQ+6gl1Eqlfj5L37ZUM7k2dVqlQXzF/Da178O1q9BrN+EFXkgD8YFIxFGxpWROgO0JH7tc4A2DJD0Hye1X2CtwFqJNcmmsFphtYMNXWzgYnwPE7iTGCT9iMhw9sBD4egTsa87Fvv6N1F95VGsHBzm/PPO5+vf+CbFYmeD86PMeIgjDz+SU047FbN6FeKhxzFdu8GKRwhvuoFdd9uNr3/tq1SrlRb20FrT2dnFsmX3cclFFyOAc8/9NMlLss1ijOHqb3yDjq5O9HXfgTVbMaIbG8i2Rm16YPS1170R3vAm7OuOw77+TYztdyh/+OPdnHTSyTzx5BPkcvkaAIQQOI6D71f4xDkfp6ezk+DWW7EjGmM7sG4P1njRplXKJ4mfRCNzT/KzARmtAFFPGGIQ1G5oBFgJRmK1ikaltIMNHWzgQeBF+0ntocnni/zsZz/n3nvvxRqDsLZmR9/32bBxE8MjQxSLnfVSxTnDyMgQu+yyK9dffx2e6xJcfwNiHBAONj8b8aNbCA49greeeQbv/Z/38L3rr6O7u7ehZodhSD5f5FvXfpuNmzazfPkKCoViQ67hOA6jo8Oc/dGPsfiNxxDcfTfiVwOYntkwNIzVk7d3jTHk83k+8MEPUSwWsFo3jMqOjY2zZu1awjCks7Pe1E06joaHB3nHme/g7E99Er1hA/zqNqzTC3SA04UwLhgXaxzQqs4E8dYwIWiHmoEILGkkRc63RoJVNRDYUEUACGMAhJMDwNpoGHRoaIhNmzbRPEwppcR13YaMWAhBGIZMTIxx+OFH8P3rruOAgw4k+K+fY5cuw3b1R80jKSGw2H//NuabX+DKK6/kjjt/z5pn1jTUMIj6I6rVKtdffx0dHZ0NcT+i/hL77bs/l152KXpkFPP16xF0gu9BkJsSAMl9nn766cwkVilFLpejUCg06FkqRZ1TH/3ox/jKlVdCqYT+4jdh0Md2dCC8XqzNI4yLMA6YyPlWi3pIiPO1pOJOFqTahgAL9TCAjOg/vmH7EJDD+NMLAclwb0dHMd5HW6FQQCnVYBStNbvsMpfvfve73HffvRx48EH4f1iG/uJ1mFw/pupgwjzGdzFOD/bRDfjX3ERvfx/XXnN1pgMSIHZ1dWf25RujufobX6ezq4vgmpuwqwYxqit6lu9hwun1eedyuQb9ki2Xy2GtbQJ5wDHHHMP999/PVVd9Dakk4Veuw9z5ECbfjwlzGNmBDRxM6ESVTyusjiumEVEYMKKh1k8Wpdq3AmrzzZK+hDoD1ABgYgDoKATYaTDA9koSm8fGxrnuuuv52teuwvd9vMMPQbz9VMy2AKvzWN/FhnlsxcEWZ2GW3IH/+/t545uO45yzz2Z8fLSlVZB2QCJJ1v/PH/oQxxx3LP7v78f89x+whVnRvQMP7XvTYoDJpHksJAKk4vHHn+Cyyy7j9ttuj3488p0nY/c7EDMUYqsuZsxgA4X1JTaU2FBEANAydryo5Wz1HI46kzdJKwAamg6iYbPpHCAJAToKASZwMcH0k8CI0ieYmCjF+2grlUr4vp/8cmbNWKVSmbvuuouPf/xsjj/+zWweHSb3yXcjjnktemuA0bmoDDqPCXJYigRX/JhwcJRLLr+MQw85lNHREZRqX3OllEyUJth3n/247IrL0SPjBF9cgqUY3TvMYcIcdpohAKBarTbol9YzDEOUUjUgCCHYuHEjN9+8hGOPO45LLr4UZ+/dca74GLbYj5kQmG0BZtxifYnxJQQJ/YvYLymfGdo6PpEptYjyAJkCQUw3ujEEmNDF+h5miiQwofS+vj522WUeVicUU5fh4WFWr30GKQXFYgfGGKSUdHZ24TgOS5cOcOrJp/K73/2W3Gf+ntKyZ7BD4+C58axYCyqHXTVG9Yqb6bjiPXznO9/hzSecQLlcyRx8gbgWCsE3rrqKrq4uJi78IfrJYURfV9TjJqPmlvU95DQAYIxhr732ipLAsLHDKAxDNm7exLbBreTzRVTcc+m6Dvl8L8YYPnfB+RQ8j0995tOYs99O9TPfR1iF3VJF9UiogAkEMowYIMoBoooazQVJ4n/7LGCSZmBqg4ZmYI0BTNwCCJ2o9icAmARxSikqlRInn3wSy5ffz58fWM6KB1fUtuUPruAvT/+VX//6f3j5y19OqTRRYwJjDL7v09vbz933/JFLL74E1deJescb0cNEZai6mNDDVBys10142xOEW4Y54sgj2Ocl+2Q2DZNyTUyM8bbT38pxb34T1RWrCG/8M3T0YypOVPv9WEc/hw0nB4CUkkqlwrevvYbly+/n/pSOKx5cwYpHHmLFIw9w5ZVfwXXdaExDRNl7GIZYa+no6OKznzuf5fcvJ/d3r8QeuA9mxGKGNGbcYHyJ9eO+mDgENDBAmvrb+GTqnkCSm0SOj1ggiv+kQgCBG+cB0+wHiGugvncl/s3L8H/6F/xb/kJ4ywq6Hhrk+OPfxK23/pq9Fu1FtVptGFcPgoBCocg1136b9Zs2Ujz9VdiuPmxJRblAxcWaPGarxvnA8Ti79vPNq77Bn+69J3N0EZJmW4Hf33UXTz7xJN6+8+GIA9DbDFbnsNUo0bVBxHRWT3Pig4rK7f/8L/j/vSLWcwX2lw+ywHTyiU+cw7XXfouqX23JCZRSBIHPF674AghwTzwcM6Ew4wozbKKOtyDOBeJWAEkyWMsFWkzeINn9ADFckmZg0rlgiVkgZgJjFMY4aOOitYfWOayOQ8BUi43Gc9RKN9yL/70/IWZ1RKNaIhqbdz7yOvrPO5H/8+53c/4F5zfMDYio0mN4ZJBf/+JXvPef3oveezfsn9ciOj1AYEeryJe/hOL7jmLVylV87sILyOVa5xekDe66HmvXPcNZZ32I3972WwqXns7Iyd+GskY48UsXAowOoybYlBKHDQMjn7oFMVQBN36t2wK9Bbp/8A+8853v4IrLruDhR/5KsVgfztZak8sVWHrHHWwbH6H/dQcxnrsdWZHYcQuhRMT0L41EmiTxE4jY+fUQkB0G2jKAjS+w8bGJN41EIwmRBEh8FAGKCi5lPCpMkwFiCbs6qc6dhT+7P9rm9lPt6GLi1qcwxrBwr0VtrxVCsOL+FWDBLJxLOVRUZI6ydSg7OYoXvwXhSD5+9jkMDg3Wml7tRGtNd3cvt93+O77yxSvxFs3G++zxlMYtFelRNg4VPMp4+Nvz0osAf3Yf/pz+aJvdTzB/DuXNPuU7VmKNZffddsOYsIUFXNdly7atPP7oY4iF/VR7uyI9fYlvFKGJ/KFFvCFrvrK1rb20gXFykag5vw4CGW+KUCg0DiEOVRwCXMQ0AZAArDIWMrbJxwldrDYgBbZq6Dx9EVJKNm3clH29tVhrGRoaimplV5GydXFUjnDrOL0fezWFwxZw43/eyE9/fgtdXa3TtpWSaN067axY7OT8Cz/Hsce+kUPf+QrGlq5h4hePofoLYEHj4sSms5MkWCllmdgaYId8RO33twLo6qTvFbsjpGDz1q0IoVoAGk2PCxneNgQuVHMFjNF4VoFVOEJhUaj4rSCJwMYvwIhUJW4nk/JYUvutEBghMELW9qFUhDiE0iGQLlXpEQgPISIATBUBRDx7uPcfXk7n61+CzKlasuLu0knx1QvwfZ8f3vhDHMdtneUT15RcLgdE76dUVA5ZAveg+cw++3Vs3rSZcz/9aXK5fKZhx8bGKBY7GnVODxh94IPc9Yc7mXPxsYws34I/XEXmHQKhyYnpMIBAxO/uz/vyiYgARPIypxQUD56Hu1cvt912Ow889EAD/afLA4J8PgcWKlphpIeVHjJ+B1IIhUi//iYEUkR+Q9SBkCUtAEgG/JK4YUWdShIGSMKAFpIARRAzQBUXOd0QEJepeOTuqCMbP5qwVf54991cdOFFrFixom3iBrDnwoXRNZsqVFQOtGTfCxajii6fPutfWL9hXctYQDKZ5NRTT+O2224jDBupNxkwum/ZvVx4wcVc/vnLmHvh0Tx11q24RY9AhITT/NF0qyPg9Z50QMs8060j2/jlddfzr5/9bNu5AMYYioUiuy/cAzsYUB4HnBzCzeE6HkI5SOUgpAIp46n4MvJbPBVeAGa73gyiqSVBXPtrsSai/0A4BMLBFw4VXCq4qCkA0DIYpJsnLFjGxsdZs/YZwjBo+2aRMRYhJG845g1gYWR1iYkJwW4fOIi+1+/Jr37xK75/w/fp6mykfqWifv6DDjqY/7p5CR/56Ef51reuyRww6uzo4ktf/hJvfvPxvOHEN7D1nevYdNPjoHJT5gD1waCzUv0A9eEgrQ1btm1l0+YNeF4e13VbWCqZiXTg/gewaI+FDN+xjvFRcLryqHyBwHGRjotWCiGTrf4uhiXeiwgENgNkTQCwqUKKGv3XWEBIjKgnHBEIFL5wqAqXsvBwxOQAmGowKHJS60BJ8+el0gSHvvQwXvOa1zCyfAuDj5Uo7D+XRZ86ktGRUc7++DmRUZvubW005fzzn78C5Sguv/wybr99gKeffpp8vnHAKKHTD5x1Fvf96R72+uyr2PLnIUYf3Ea/fHaDQcmQb1dXD8aYzORUKQetA/7+79+FEpJnbl1N2TjkvDz5niLa89Cui3YcpKOwSmGljDYhsTJ2fvKyTMYzWlsBsf9t6kQCAiMERkqMlGip0FLFOUAEgCoe1WmGgHaDQVkDJc1GjT4LueKKy3GVw6PXP8rYuGCf844g15fnc+dfwJNPPU6haYZw1M8/wqmnnsYJJ7yZ8Y1j9PX1ce2138JmTO0yRlMsFnnssUc499OfIdeTZ79LX0XJuATTbAW0GwwqFou4rpv5XgBE8x5GRgY5+KCX8uGPfJjK5jJrfrOJoKODsKMA3UV0zsXkXKzrYh0HoxRWRa/BWRk7vX0LMLJn1sloEDC6QY0BhKxtUTKoolAgHYLY+WU8qkxvMCh54ydryzJIMkzs+z7j46N8+YtX8uYTj2f97zfy2I1r2e0f9mPB8Xty151/4JvXfJPOjq6muB/RekdHF1dcfhnWWO54z908fcsqFi8+ik+c88nMAaMwDOnq6uHab1/Dz275GfNevSu7/9MBjA22gvPZ6pnMeXAch5GRIXabv4CbbryJzs5O7v/8A4xuMfheDjGvG9uZx+Zz2JyHdR2sUqBkjQGQSb9FjIA2QGjz2kpc+NqFMQji2m+UwiiFVg5aOYTKoSpdKsKlEkeVhOKe7ZYM3pRKJUZGhujv7+eG7/8nnzz3Eww+OcrA2SuQC3p4+XkvQ4eacz5xDkopXM9ruE8ul6dUGucjH/5n9tt/Px65aSVrl41z35VPMLGlzMUXX8jLDnsFpdIEuVyupQzFYidnf/zjDA0Ncfh5r6DvyDkAKEftFD2llGitGRsbYXR0mMVHHcPSpUs5+JCDePA/nuTRn2wk7Cpiezpw53dhizkoepB3sJ4DrsI6EpwICDXnp7cMBLTtBwAbdypJrLAxsuK9UhhlMI6DdlxC1+DLqCPIxCvQB75PGAYMDw+2rx7TlEK+g5ce/FJOPeUUPvyxs5g7ex5r793G7Z98kKENIW/8ykspzs3z0Y+czZ+X3QdAtVppuc/8+Qv4l3/9F8qDVf709ZWIuV1seSbk9xc/wpu//nK+fe21vPLVr2JoaFtmOVatHufMM9/BL375M/Z/1yKshbHxMcIwZHBw67PUUjCrfzZHvf4o/vE9/4d3vPPtAPzpqidY9tUncTqLWE/St3c3oqeA6PQQRQ9yLsQAqDlfiToDyFTtz2CAbADEtT7a29qNrBRYJTHKYh2FcQ3addCuwVceZQLAxRrL3nvtzefOvxAv503a+9ZOlFR093SxYPfdOODA/dj3JfsD4A8bln7hcf7y/XXo0OLM7WLv4+ZTqVSYP383Lr7o0ihPaJplVK2UOeoNi+nr6+X2ix9jyzpDod+DHo8HfjrIgqPXc/jpr2DJj5bwwIN/iWYQNeUFUkjKlTJbNm1lwe67AXDmmW9n7733bplxNF3JeR6zZs9i0d4LOfilBzKnfx4A6+4f4Q9ffYrVdwzidRYwrmD2vp14uxSRXS6yy0MUHUTeRXgqAoCSCCVTIEjlAUhExjIxIv7NQDs8PNw3MlJ6atdd5vZJhDXaChNadGDRviGsGoKKISgb/AmNP64pjwRMbA2Y2BawbsUomx+dQAeWt1y+D4e+bd52G6Od+IOwavkgj/5uC08PDDG6vkquy0G6kupYyBs/s4hXv3/BtO618o/D/Ph9DyOliNaRRKB9g1dUvPMHB7HrQV3Tus8zy0bpmO3Sv2dhxxVrkuGVAU/8cQuP3bqFZ+4dQ1cNbqeDm5fMeUmR3t3zFHodiv0u+R6XfLfC63DwihK3IHHyCicncXIC5UqUK5COQEiBVNJqE4qNm7Yhpdp/wYI5j1lr27RlklWpE9qQMaUkq5C4NlqvMGcRBRAFKMzvQK/WVI3mpxet4b6fbEN621/zE7EG/JKmPBwysS2kMqKxGtyCwunvIFQCoy0673DrV9bz0G2jqHwygyjjfhasho0PlwlwUVJQ7HEwGvyxkPKE5fp/fJy5B+SjnGmyHl4jWbt8nHyXYva++bbPnI6Y0FIZ05QGQ0rbQvwJg5ACt5jD6RV4/Q6zFhXonOPidCvc3mjvdDrIgkLmJMKTCFciHIlwRMQCspEB4qkMLdIKAJHaSxEvPCXipWdE/BAQrohWZSuCLENhnqD/AFj7UIlK1fLXu8tTrU0wpYi4lirHRXXmIkR7ArdD4hUUQcUwtiUgDCyP3lvBtlkFI62bm3dQriA3y8HpiRLMQIVUhjWVccOWO1tzh6z7eEWX8UHLxqXlZ6FhXU/pSJSbQ/UJHE+S75b0zPPomuNS6FJ4XZJcj4PbpXA6JaqgUHmJzEmkJ5CuRLoy8pEUSJW0/6nts1CayQC1loNIupdFvDq5RCgbrcLmRcvyOUWBG0hcLZm9n0IUPbas9qmWTePywGSPR7e3SvR8pUC5Ai8v8YoSLy+RKrqXa0H1GiYGQ1S1/kJE1mMS3R1X0NGnKPao2gox3T3gDGsmhkOcsP090pKUwWkJq81Xtq8CiZ2ljHR0c5J8p6TQrSh2KbwOSa4gyHcq8p2SXIfE65A4BYUqCFSD8wXCiSk/BkG0LqaYtBZmzwcQyT6akFlbxzBezlZpgfEkbhgN4ecMmHixQpVTdO+So1IyhL5Bh1F/ePKKfDSK175AtUfHz5VKRM9VIlrmJ6WUNZYOAz27etHyPtrGoGt6gBCIlKGVE91LqmjU0xpLsd+lL7CEoY3WirSAbe5HTN8yainVHjUZYpockIAxqVhKiVq5HC/avJzALUhyRUmuKPAKMtryEi8vcPMRUyTfl45AKRHbS9TslF4mKSsGtG0FiNgTQtrYEVFttAqMKyJD52Vt+rgQ0fI7Xl6QKwiKVUkYWHRoo8U3jK0xwqRMkGYrQZSsiRiAscGSmpss72digNWekdwr1bMtYlDJWJfESBCvqKIjx5t0OZN7ZEm619w2ns5QqQEENYaV0UphQsUgcCKAOp7EzUVOdnMSNy/wctE5JyeifeJ8NwZPnPDVnZ9u/ov6c5ukBQAJWKyMkiYRO8FKsE60AEXjkjORFWWMYjcnCaqG0I9bELpu3KT2t9SaZuPE5xKn1UKRoDaMnFxvra0DIfZaMwBqtxR1ADX0i9jk+ghEpMo4rRre5uMWezeAsa5PwgIyAYAjUJ7AcetOdnJ1dnBc0ej8Wu1PL4AWA1xM/mJIdhIYvXyLlBG1C2mREqwSEQgSAyW1QEiksihH4HqG0Bfo0NZouU7NydYuUEd/asilMR9JPmsweup+MWu3eiQdBhvuHR3U1xGgyfntq/aU6UyaIWh+vkgBIE4Ca+EuZgKnXrOVEzvbi8HhgnIljgMyCWkxi0TrYqaATmM5mqXtkJaA2q+tCJJ4aeMXDlLKJN3OCpQDjivROWLqj+jfNNN/k4HTY+FpBqjtEhC0s3XqnrX/m5VJH2bdqJk5Wu5lG1o1LQCYRu4nmqg4zWqJDaMWgUApor3TBIhavkCN8mvOV03gmsxosbQf0xQCEXcHRz87bZFWRNU/5Z2aAsqiHYt2bbziqk3F5hRVp4yVGLfFKU01Nm20ZrFQXw8xfbKtXpN8Zht2k4NqqudlAqDxOEnOZCo0yTiDV0niGzs/YYZon0qMU/lMkuPUEuWM5zbLFAwQJ4EWkAKZZHvxKwcJhUkZvSgsnbiFEFqMEVH2b1MASGrq5BEgu+ANYBYkd8hyVu3fVI4xRUWoX9dcsO0B12TSxGgNLYGmUJDQeN3JrQ6XMuX4hPZFk/PF5M6HSRkgrllCIGXcjItBIJzowyTRMDJe+8BEvXPWFY1ZuW0CAK2Gng4LZFo0kSli9LQBkHXxNPoFpiPNDNCc6JJyZC0cJOdUep+O801J8nY4H6Z6NSwBgYzDga2fVELU1iJOmonRqvIi5fj42EackU6wgJZEKctQSTlSuwbZKbUzS9o5/dk8o01eEzm/MTFMh4U0MyTHSWiuHcs45sO0nQ+ThQCRYtA4BCQLOVgjMNLWmzFJnDdEq5M2JHyisVMlI65mFrbB6VnpNBnOaN9xk3HrpiunOjFFHjCd57YwnKg7q8YG1Jyb1Oo0vTe0ImrNWdHAoNszLjEpA0R5QHxs6zkBIqL7xLFKRCxhU85PanvN6VbU3TPtJK1RsUklYScmg8HkbeLM63Ymq9SLUS9NOh9IO78FGPXvtjge2J5an5YpZzY2g4BaQWJqT5YjIW7WyTrdt7ap4w6GRFJJWuMTU1+YoiOj+VbUnjPJt7Is1fa61vI2F7tdQtuiXvNBkuek9rXiNTFEQ39Ik+PbqTQdmdbk9qRwDSGhCQiRs+MamHzRpmpVrf9ge0oqtu/ryTVta+1k92t33Q5adjrSENlEizMbO8HYqY5PJA0AYRt6eTLKG3+aBYT4BtHnDQBoumhHZLso4AUmaUw2OzXpOGr6vOE7O/LIFI6cpNnQ09MzOjg4MQyil7b5eePDGyjO1j9oTCBfqJ75G0qTN7McnvG1HRJrzbjjiOHkXyc6aYUQIly1av2QEGLhdG/WnNWmfS2av7QjOHg2Ck+zd25a1z1XMkl5doaz2zxwbO7cuSPJmXjl4uj3xowxq4TgZWQtbT2d209W6OcwlO7U5/2ty/m3EyOlVMbYtUKIclzpa06O1ZaPZLyMMyMvDrFxj+wTAEuXLlUQ/+TV0qVL42/o5ZVKFWPMi7ce/D8sYWgQQi4DWLx4MRDT/OLFiw1AodBx3/DwsK+1jdcxmZEXi4ShlqOjYwhh7olPWYgBIIQw1loxf37/aq31ivjnzLb/LYcZeb6KASEnJibWWrvb/QBSSg2NiV78uqv4mTGZY2Iz8sKVeJRG/s+iRaIyMDDgJJNxZOOXIJfzfrJlyzbj+8FMGHiRSBCEcmxsQkgplgAsXry45tcaAOIwIOfPn/1IEIS/jdf6mQkDL3wx1koxPDz88B57zBuIm381vza39QWA4zhXlUplsb0/hjwjzz8xxhitrRBCXi2E0EShvpUBAIQQ2lorFyyY8+vBwcFlWovkB+ln5IUpxve12rRp87piUf0gHutp8GdWb58QQhjXVeeOj5fx/Wn+DNiMPO8kDLUJQ4SU/Nu8efPGASlE4wJ+LQCIWUDtvvuuA6Ojoz+yVikafit7Rl4gorXG2bJlyx/32GPXHyxZskSJjAUCMnv8rI16CDdu3Dg7DNVDs2b1zC4UvMlmWszI80tspRKYwcFRLQSHzZ8/+xFrrcwCQKZD4y+KXXfddbPW+j3lsi+q1SDrF5Bn5HkoQRCGWqN83z87dn5m7YdJarQQQg8MDDgLF+76y+Hh4Uu1lk4QzDQLnu+itQ60lu6WLVu+v2jR/G8NDAw4cfa/QyIGBgYcgNWr191QLmsbBKFvZ+R5KVprv1LRdvXqjbdZa9WSJVbZKWZ5TRXT7eLFi7W1Vu2xx/x3b9685UdhKNwgCGeaBs8zCUMd+D7u1q1bl3qePRkwDz98oW3O+ndIrLXiggusFAKeeWbTf5ZKoS2Xq6G11vyvQn5GrLXWVKt+UC5r+8wzm3+3bt26YuyzaSXs0x73t/HvkAkhzJo1m6/o7Oz4TC6nKBZzIdOcXTwjO110qVRRxkiGh0euf/LJh99/9NFHh7ZNxp8l2zXxIw2C1as3nOG67jX9/X2zhNDa81zBTDPxbyUmDEMThsIZHh6paB1+csGCeVfH/mF7aH+7HCaEsPGgkdpzz11vBv8VW7duu6VUClWlEsow+pXnmQGk506M1iasVAJZqRhncHBkaakUvHLBgnlXL1myJFr1cDtj/g5P/bJR21IDrFu39TSwF3V3d7/U8xSgred5mniRuR19xowAUYUyQRBKa4UMQ8vw8MhKa7l0wYLZ3wMYGBhwjj766B1qoj+ruX8XXHCBvPDCCxFCmIceesjr7d3lnVLyPsdxXtfb203Ub2RwXScpnEhtM5IttQ63IAhVsljj2NgElUp5hZTqP8bGtt6w7777jqZD8o4+bKc4Is0GAOvWbX69EOJ0rc0JjuPs19vbg+Oo6IWR2vq7M52KrSIQQhL9eKRhbGyMatVfJYT4jevKn8yd2//bxNnNNt/xJ+4kidEoAZPEoT//2bp77jlySLUavNIYfYQxZn8hxAIhRJe1tlski+39v80I0fw7a8eFEGPWsg7sE0qpZa6r/jR3bv/9QojacqQDAwPO4sWL9U5p3/McGX7JkiVqzpw5IisuWWsLQMe6dVtnPRfPfiFKLgda54fnzescF0JMNH9urY0TPAxT/h7b80istcJaK621jrVTd0vOSM1mylrrLFmy5Dm32d/cISmFZsDQKNESFzuJ2qcr/z9KSBqffttWZQAAAABJRU5ErkJggg=='
  $octets = [Convert]::FromBase64String($logoB64)
  $flux = New-Object System.IO.MemoryStream (,$octets)
  $img = New-Object System.Windows.Media.Imaging.BitmapImage
  $img.BeginInit(); $img.StreamSource = $flux; $img.CacheOption = 'OnLoad'; $img.EndInit(); $img.Freeze()
  $Logo.Source = $img
  $window.Icon = $img

  # ---------- État partagé avec le thread de travail ----------
  $sync = [hashtable]::Synchronized(@{})
  $sync.Queue = New-Object 'System.Collections.Concurrent.ConcurrentQueue[object]'
  $sync.Event = New-Object System.Threading.ManualResetEvent $false
  $sync.Answer = $false
  $sync.Question = $null
  $sync.Progress = 0
  $sync.Statut = "Prêt"
  $sync.Fini = $false
  $sync.Occupe = $false

  $conv = New-Object System.Windows.Media.BrushConverter
  $couleurs = @{ titre = '#1DF28F'; ligne = '#9A9A9A'; ok = '#4ADE80'; alerte = '#FACC15'; info = '#D0D0D0'; fin = '#38BDF8' }
  $script:cheminRapport = $null
  $script:ps = $null
  $script:handle = $null
  $script:restaureUI = $false
  $boutons = @($BtnVerif, $BtnMaj, $BtnOpti, $BtnAll)

  $libre = [math]::Round((Get-PSDrive C).Free / 1GB, 1)
  $SousTitre.Text = "$env:COMPUTERNAME  •  C: $libre Go libres"

  # =================================================================
  # OPTIMISATIONS : outils registre
  # =================================================================
  function RSet($p, $n, $v, $type = 'DWord') {
    if (-not (Test-Path $p)) { New-Item -Path $p -Force | Out-Null }
    New-ItemProperty -Path $p -Name $n -Value $v -PropertyType $type -Force | Out-Null
  }
  function RDel($p, $n) { Remove-ItemProperty -Path $p -Name $n -ErrorAction SilentlyContinue }
  function RGet($p, $n) { return (Get-ItemProperty -Path $p -Name $n -ErrorAction SilentlyContinue).$n }

  $CDM   = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager'
  $ADV   = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\AdvertisingInfo'
  $EXADV = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced'
  $EXP   = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer'
  $POL   = 'HKLM:\SOFTWARE\Policies\Microsoft\Windows'
  $CLSID = 'HKCU:\Software\Classes\CLSID\{86ca1aa0-34aa-4e8b-a509-50c905bae2a2}'
  $SYSPROF = 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile'
  $TCPIF = 'HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters\Interfaces'

  $tweaks = New-Object System.Collections.ArrayList
  function Tw($tab, $titre, $d1, $d2, $reco, $test, $on, $off) {
    [void]$tweaks.Add(@{ Tab = $tab; Titre = $titre; D1 = $d1; D2 = $d2; Reco = $reco; Test = $test; On = $on; Off = $off; Action = $null; Etat = $false })
  }

  function TwAction($tab, $titre, $d1, $d2, $bouton, $reco, $action) {
    [void]$tweaks.Add(@{ Tab = $tab; Titre = $titre; D1 = $d1; D2 = $d2; Bouton = $bouton; Reco = $reco; Test = $null; On = $null; Off = $null; Etat = $false; Action = $action })
  }

  # ---------------- CONFIDENTIALITÉ ----------------
  Tw 'priv' 'Supprimer les publicités Windows' 'Élimine les messages promotionnels intégrés à Windows.' 'Réduit les interruptions et distractions inutiles.' $true `
    { (RGet $ADV 'Enabled') -eq 0 } `
    { RSet $ADV 'Enabled' 0; foreach ($n in 'SubscribedContent-338387Enabled','SubscribedContent-338388Enabled','SubscribedContent-338393Enabled') { RSet $CDM $n 0 } } `
    { RSet $ADV 'Enabled' 1; foreach ($n in 'SubscribedContent-338387Enabled','SubscribedContent-338388Enabled','SubscribedContent-338393Enabled') { RSet $CDM $n 1 } }

  Tw 'priv' 'Désactiver les suggestions Windows' 'Désactive les suggestions et contenus sponsorisés dans le menu Démarrer et les paramètres.' 'Allège l''interface et réduit les sollicitations système inutiles.' $true `
    { (RGet $CDM 'SystemPaneSuggestionsEnabled') -eq 0 } `
    { foreach ($n in 'SystemPaneSuggestionsEnabled','SoftLandingEnabled','SubscribedContent-338389Enabled','SubscribedContent-310093Enabled','SubscribedContent-353694Enabled','SubscribedContent-353696Enabled') { RSet $CDM $n 0 } } `
    { foreach ($n in 'SystemPaneSuggestionsEnabled','SoftLandingEnabled','SubscribedContent-338389Enabled','SubscribedContent-310093Enabled','SubscribedContent-353694Enabled','SubscribedContent-353696Enabled') { RSet $CDM $n 1 } }

  Tw 'priv' 'Désactiver les recommandations du menu Démarrer' 'Masque la section Recommandé (apps et fichiers récemment ajoutés).' 'Épure le menu Démarrer et limite le suivi des fichiers récents.' $true `
    { (RGet $EXADV 'Start_TrackDocs') -eq 0 } `
    { RSet $EXADV 'Start_TrackDocs' 0; RSet $EXADV 'Start_IrisRecommendations' 0 } `
    { RSet $EXADV 'Start_TrackDocs' 1; RSet $EXADV 'Start_IrisRecommendations' 1 }

  Tw 'priv' 'Désactiver l''historique d''activité' 'Supprime l''historique des documents récents et des activités envoyées à Microsoft.' 'Réduit les données collectées par Windows en arrière-plan.' $true `
    { (RGet "$POL\System" 'EnableActivityFeed') -eq 0 } `
    { foreach ($n in 'EnableActivityFeed','PublishUserActivities','UploadUserActivities') { RSet "$POL\System" $n 0 } } `
    { foreach ($n in 'EnableActivityFeed','PublishUserActivities','UploadUserActivities') { RDel "$POL\System" $n } }

  Tw 'priv' 'Désactiver Windows Recall / analyse IA' 'Désactive l''analyse de l''activité par l''IA intégrée à Windows (captures d''écran en continu).' 'Sans effet si ta version de Windows n''a pas Recall.' $false `
    { (RGet "$POL\WindowsAI" 'DisableAIDataAnalysis') -eq 1 } `
    { RSet "$POL\WindowsAI" 'DisableAIDataAnalysis' 1 } `
    { RDel "$POL\WindowsAI" 'DisableAIDataAnalysis' }

  Tw 'priv' 'Désactiver la télémétrie Windows' 'Réduit la collecte de données et coupe les services de suivi (DiagTrack).' 'Réduit les charges invisibles pouvant ralentir le système.' $true `
    { (RGet "$POL\DataCollection" 'AllowTelemetry') -eq 0 } `
    { RSet "$POL\DataCollection" 'AllowTelemetry' 0; foreach ($s in 'DiagTrack','dmwappushservice') { Stop-Service $s -Force -ErrorAction SilentlyContinue; Set-Service $s -StartupType Disabled -ErrorAction SilentlyContinue } } `
    { RDel "$POL\DataCollection" 'AllowTelemetry'; foreach ($s in 'DiagTrack','dmwappushservice') { Set-Service $s -StartupType Automatic -ErrorAction SilentlyContinue }; Start-Service DiagTrack -ErrorAction SilentlyContinue }

  Tw 'priv' 'Désactiver la géolocalisation' 'Bloque l''accès de Windows et des applications à ta position.' 'Réduit les accès réseau en arrière-plan.' $false `
    { (RGet 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\location' 'Value') -eq 'Deny' } `
    { RSet 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\location' 'Value' 'Deny' 'String' } `
    { RSet 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\location' 'Value' 'Allow' 'String' }

  Tw 'priv' 'Désactiver la reconnaissance vocale en ligne' 'Désactive les services de dictée et d''analyse vocale connectés.' 'Réduit les tâches actives pouvant provoquer des ralentissements ponctuels.' $false `
    { (RGet 'HKCU:\Software\Microsoft\Speech_OneCore\Settings\OnlineSpeechPrivacy' 'HasAccepted') -eq 0 } `
    { RSet 'HKCU:\Software\Microsoft\Speech_OneCore\Settings\OnlineSpeechPrivacy' 'HasAccepted' 0 } `
    { RSet 'HKCU:\Software\Microsoft\Speech_OneCore\Settings\OnlineSpeechPrivacy' 'HasAccepted' 1 }

  Tw 'priv' 'Bloquer les installations non sollicitées' 'Empêche Windows d''installer automatiquement des apps et jeux depuis le Store.' 'Allège le système en bloquant les installations en arrière-plan.' $true `
    { (RGet $CDM 'SilentInstalledAppsEnabled') -eq 0 } `
    { foreach ($n in 'SilentInstalledAppsEnabled','PreInstalledAppsEnabled','OEMPreInstalledAppsEnabled') { RSet $CDM $n 0 } } `
    { foreach ($n in 'SilentInstalledAppsEnabled','PreInstalledAppsEnabled','OEMPreInstalledAppsEnabled') { RSet $CDM $n 1 } }

  Tw 'priv' 'Désactiver les retours d''expérience' 'Empêche Windows de te demander ton avis et d''envoyer des retours à Microsoft.' 'Réduit les fenêtres et notifications intrusives.' $true `
    { (RGet 'HKCU:\Software\Microsoft\Siuf\Rules' 'NumberOfSIUFInPeriod') -eq 0 } `
    { RSet 'HKCU:\Software\Microsoft\Siuf\Rules' 'NumberOfSIUFInPeriod' 0 } `
    { RDel 'HKCU:\Software\Microsoft\Siuf\Rules' 'NumberOfSIUFInPeriod' }

  Tw 'priv' 'Désactiver les rapports d''erreurs Windows' 'Empêche l''envoi automatique des rapports de plantage à Microsoft.' 'Réduit l''activité en arrière-plan après un plantage.' $false `
    { (RGet 'HKLM:\SOFTWARE\Microsoft\Windows\Windows Error Reporting' 'Disabled') -eq 1 } `
    { RSet 'HKLM:\SOFTWARE\Microsoft\Windows\Windows Error Reporting' 'Disabled' 1 } `
    { RSet 'HKLM:\SOFTWARE\Microsoft\Windows\Windows Error Reporting' 'Disabled' 0 }

  Tw 'priv' 'Désactiver le suivi des applications lancées' 'Windows arrête de mémoriser quels programmes tu ouvres le plus souvent.' 'Limite le suivi de ton activité et épure le menu Démarrer.' $true `
    { (RGet $EXADV 'Start_TrackProgs') -eq 0 } `
    { RSet $EXADV 'Start_TrackProgs' 0 } `
    { RSet $EXADV 'Start_TrackProgs' 1 }

  Tw 'priv' 'Désactiver le presse-papiers cloud' 'Coupe la synchronisation du presse-papiers entre appareils.' 'Ce que tu copies reste uniquement sur ton PC.' $false `
    { (RGet "$POL\System" 'AllowCrossDeviceClipboard') -eq 0 } `
    { RSet "$POL\System" 'AllowCrossDeviceClipboard' 0 } `
    { RDel "$POL\System" 'AllowCrossDeviceClipboard' }

  Tw 'priv' 'Désactiver la collecte de frappe' 'Windows arrête d''enregistrer ce que tu tapes pour améliorer la saisie et la reconnaissance.' 'Réduit la collecte de données personnelles.' $true `
    { (RGet 'HKCU:\Software\Microsoft\InputPersonalization' 'RestrictImplicitTextCollection') -eq 1 } `
    { RSet 'HKCU:\Software\Microsoft\InputPersonalization' 'RestrictImplicitTextCollection' 1; RSet 'HKCU:\Software\Microsoft\InputPersonalization' 'RestrictImplicitInkCollection' 1 } `
    { RSet 'HKCU:\Software\Microsoft\InputPersonalization' 'RestrictImplicitTextCollection' 0; RSet 'HKCU:\Software\Microsoft\InputPersonalization' 'RestrictImplicitInkCollection' 0 }

  # ---------------- CONFORT ----------------
  Tw 'confort' 'Désactiver les effets visuels et animations' 'Supprime les effets graphiques inutiles de Windows (transparence, animations).' 'Améliore la fluidité de l''interface et la réactivité globale.' $true `
    { (RGet "$EXP\VisualEffects" 'VisualFXSetting') -eq 2 } `
    { RSet "$EXP\VisualEffects" 'VisualFXSetting' 2; RSet 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize' 'EnableTransparency' 0; RSet 'HKCU:\Control Panel\Desktop\WindowMetrics' 'MinAnimate' '0' 'String' } `
    { RSet "$EXP\VisualEffects" 'VisualFXSetting' 0; RSet 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize' 'EnableTransparency' 1; RSet 'HKCU:\Control Panel\Desktop\WindowMetrics' 'MinAnimate' '1' 'String' }

  Tw 'confort' 'Désactiver les résultats web dans la recherche' 'Supprime les suggestions Bing et du Store dans la barre de recherche Windows.' 'Rend la recherche plus rapide et moins encombrée.' $true `
    { (RGet 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Search' 'BingSearchEnabled') -eq 0 } `
    { RSet 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Search' 'BingSearchEnabled' 0; RSet 'HKCU:\Software\Policies\Microsoft\Windows\Explorer' 'DisableSearchBoxSuggestions' 1 } `
    { RSet 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Search' 'BingSearchEnabled' 1; RDel 'HKCU:\Software\Policies\Microsoft\Windows\Explorer' 'DisableSearchBoxSuggestions' }

  Tw 'confort' 'Supprimer les widgets Windows' 'Supprime les widgets intégrés dans la barre des tâches.' 'Réduit les processus actifs en arrière-plan et allège l''interface.' $true `
    { (RGet 'HKLM:\SOFTWARE\Policies\Microsoft\Dsh' 'AllowNewsAndInterests') -eq 0 } `
    { RSet 'HKLM:\SOFTWARE\Policies\Microsoft\Dsh' 'AllowNewsAndInterests' 0; RSet $EXADV 'TaskbarDa' 0 } `
    { RDel 'HKLM:\SOFTWARE\Policies\Microsoft\Dsh' 'AllowNewsAndInterests'; RSet $EXADV 'TaskbarDa' 1 }

  Tw 'confort' 'Optimiser la souris pour le jeu' 'Désactive l''accélération du pointeur (précision accrue, comportement prévisible).' 'Visible après reconnexion à Windows.' $true `
    { (RGet 'HKCU:\Control Panel\Mouse' 'MouseSpeed') -eq '0' } `
    { RSet 'HKCU:\Control Panel\Mouse' 'MouseSpeed' '0' 'String'; RSet 'HKCU:\Control Panel\Mouse' 'MouseThreshold1' '0' 'String'; RSet 'HKCU:\Control Panel\Mouse' 'MouseThreshold2' '0' 'String' } `
    { RSet 'HKCU:\Control Panel\Mouse' 'MouseSpeed' '1' 'String'; RSet 'HKCU:\Control Panel\Mouse' 'MouseThreshold1' '6' 'String'; RSet 'HKCU:\Control Panel\Mouse' 'MouseThreshold2' '10' 'String' }

  Tw 'confort' 'Optimiser l''Explorateur Windows' 'Ouvre l''Explorateur directement sur Ce PC et masque les fichiers récents et fréquents.' 'Rend l''ouverture des dossiers plus rapide et plus fluide.' $false `
    { (RGet $EXP 'ShowFrequent') -eq 0 } `
    { RSet $EXADV 'LaunchTo' 1; RSet $EXP 'ShowRecent' 0; RSet $EXP 'ShowFrequent' 0 } `
    { RSet $EXADV 'LaunchTo' 2; RSet $EXP 'ShowRecent' 1; RSet $EXP 'ShowFrequent' 1 }

  Tw 'confort' 'Restaurer le menu contextuel classique' 'Restaure le menu clic droit classique au lieu du menu réduit de Windows 11.' 'Redémarre l''Explorateur (la barre des tâches clignote un instant).' $false `
    { Test-Path "$CLSID\InprocServer32" } `
    { New-Item -Path "$CLSID\InprocServer32" -Force | Out-Null; Set-ItemProperty -Path "$CLSID\InprocServer32" -Name '(default)' -Value ''; Stop-Process -Name explorer -Force } `
    { Remove-Item -Path $CLSID -Recurse -Force -ErrorAction SilentlyContinue; Stop-Process -Name explorer -Force }

  Tw 'confort' 'Optimisation Edge' 'Désactive le démarrage anticipé et l''exécution en arrière-plan d''Edge.' 'Réduit l''activité du navigateur en arrière-plan.' $true `
    { (RGet 'HKLM:\SOFTWARE\Policies\Microsoft\Edge' 'StartupBoostEnabled') -eq 0 } `
    { foreach ($n in 'StartupBoostEnabled','BackgroundModeEnabled','PersonalizationReportingEnabled') { RSet 'HKLM:\SOFTWARE\Policies\Microsoft\Edge' $n 0 } } `
    { foreach ($n in 'StartupBoostEnabled','BackgroundModeEnabled','PersonalizationReportingEnabled') { RDel 'HKLM:\SOFTWARE\Policies\Microsoft\Edge' $n } }

  Tw 'confort' 'Désactiver Microsoft Copilot' 'Désactive l''IA Copilot intégrée à Windows et masque son bouton.' 'Réduit l''activité en arrière-plan pouvant consommer CPU et mémoire.' $false `
    { (RGet 'HKCU:\Software\Policies\Microsoft\Windows\WindowsCopilot' 'TurnOffWindowsCopilot') -eq 1 } `
    { RSet 'HKCU:\Software\Policies\Microsoft\Windows\WindowsCopilot' 'TurnOffWindowsCopilot' 1; RSet $EXADV 'ShowCopilotButton' 0 } `
    { RDel 'HKCU:\Software\Policies\Microsoft\Windows\WindowsCopilot' 'TurnOffWindowsCopilot'; RSet $EXADV 'ShowCopilotButton' 1 }

  Tw 'confort' 'Afficher les extensions de fichiers' 'Montre .exe, .pdf, .jpg... à la fin des noms de fichiers.' 'Aide à repérer les faux fichiers (ex. photo.jpg.exe).' $true `
    { (RGet $EXADV 'HideFileExt') -eq 0 } `
    { RSet $EXADV 'HideFileExt' 0 } `
    { RSet $EXADV 'HideFileExt' 1 }

  Tw 'confort' 'Afficher les fichiers cachés' 'Rend visibles les fichiers et dossiers cachés dans l''Explorateur.' 'Pratique pour vérifier ce qu''un virus aurait pu cacher.' $false `
    { (RGet $EXADV 'Hidden') -eq 1 } `
    { RSet $EXADV 'Hidden' 1 } `
    { RSet $EXADV 'Hidden' 2 }

  Tw 'confort' 'Désactiver les touches rémanentes' 'Supprime la fenêtre qui apparaît quand tu appuies 5 fois sur Maj (utile en jeu).' 'Désactive aussi les touches bascule et le filtrage des touches.' $true `
    { (RGet 'HKCU:\Control Panel\Accessibility\StickyKeys' 'Flags') -eq '506' } `
    { RSet 'HKCU:\Control Panel\Accessibility\StickyKeys' 'Flags' '506' 'String'; RSet 'HKCU:\Control Panel\Accessibility\ToggleKeys' 'Flags' '58' 'String'; RSet 'HKCU:\Control Panel\Accessibility\Keyboard Response' 'Flags' '122' 'String' } `
    { RSet 'HKCU:\Control Panel\Accessibility\StickyKeys' 'Flags' '510' 'String'; RSet 'HKCU:\Control Panel\Accessibility\ToggleKeys' 'Flags' '62' 'String'; RSet 'HKCU:\Control Panel\Accessibility\Keyboard Response' 'Flags' '126' 'String' }

  Tw 'confort' 'Désactiver la secousse des fenêtres' 'Empêche de minimiser toutes les fenêtres en secouant l''une d''elles.' 'Évite les manipulations accidentelles.' $false `
    { (RGet $EXADV 'DisallowShaking') -eq 1 } `
    { RSet $EXADV 'DisallowShaking' 1 } `
    { RSet $EXADV 'DisallowShaking' 0 }

  Tw 'confort' 'Supprimer le bouton Teams / Chat' 'Retire l''icône Chat de la barre des tâches.' 'Peut être protégé selon ta version de Windows.' $false `
    { (RGet $EXADV 'TaskbarMn') -eq 0 } `
    { RSet $EXADV 'TaskbarMn' 0 } `
    { RSet $EXADV 'TaskbarMn' 1 }

  Tw 'confort' 'Désactiver Windows Spotlight' 'Supprime les images et astuces sponsorisées de l''écran de verrouillage.' 'Un écran de verrouillage propre, sans publicité.' $true `
    { (RGet $CDM 'RotatingLockScreenEnabled') -eq 0 } `
    { RSet $CDM 'RotatingLockScreenEnabled' 0; RSet $CDM 'RotatingLockScreenOverlayEnabled' 0 } `
    { RSet $CDM 'RotatingLockScreenEnabled' 1; RSet $CDM 'RotatingLockScreenOverlayEnabled' 1 }

  Tw 'confort' 'Désactiver le son de démarrage' 'Coupe le jingle de Windows au démarrage.' 'Un démarrage silencieux.' $false `
    { (RGet 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Authentication\LogonUI\BootAnimation' 'DisableStartupSound') -eq 1 } `
    { RSet 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Authentication\LogonUI\BootAnimation' 'DisableStartupSound' 1 } `
    { RSet 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Authentication\LogonUI\BootAnimation' 'DisableStartupSound' 0 }

  # ---------------- RÉSEAU ----------------
  Tw 'reseau' 'Optimisation de la carte réseau' 'Désactive les économies d''énergie de la carte réseau.' 'Stabilise le ping et améliore la fiabilité de la connexion.' $true `
    { $a = Get-NetAdapter -Physical -ErrorAction SilentlyContinue | Where-Object Status -eq 'Up' | Select-Object -First 1; if (-not $a) { return $false }; $p = Get-NetAdapterPowerManagement -Name $a.Name -ErrorAction SilentlyContinue; return [bool]($p -and $p.AllowComputerToTurnOffDevice -eq 'Disabled') } `
    { Get-NetAdapter -Physical -ErrorAction SilentlyContinue | ForEach-Object { Set-NetAdapterPowerManagement -Name $_.Name -AllowComputerToTurnOffDevice Disabled -NoRestart -ErrorAction SilentlyContinue } } `
    { Get-NetAdapter -Physical -ErrorAction SilentlyContinue | ForEach-Object { Set-NetAdapterPowerManagement -Name $_.Name -AllowComputerToTurnOffDevice Enabled -NoRestart -ErrorAction SilentlyContinue } }

  Tw 'reseau' 'Optimisation de la latence réseau' 'Désactive l''algorithme de Nagle pour réduire la latence des petits paquets.' 'Connexion plus réactive en jeu, avec moins de micro-saccades de ping.' $true `
    { @(Get-ChildItem $TCPIF -ErrorAction SilentlyContinue | Where-Object { (RGet $_.PSPath 'TcpAckFrequency') -eq 1 }).Count -gt 0 } `
    { Get-ChildItem $TCPIF -ErrorAction SilentlyContinue | ForEach-Object { RSet $_.PSPath 'TcpAckFrequency' 1; RSet $_.PSPath 'TCPNoDelay' 1 } } `
    { Get-ChildItem $TCPIF -ErrorAction SilentlyContinue | ForEach-Object { RDel $_.PSPath 'TcpAckFrequency'; RDel $_.PSPath 'TCPNoDelay' } }

  Tw 'reseau' 'Optimisation de la réactivité réseau' 'Désactive le bridage réseau de Windows pour le trafic en jeu.' 'Laisse passer davantage de paquets et réduit la latence en ligne.' $true `
    { (RGet $SYSPROF 'NetworkThrottlingIndex') -eq -1 } `
    { RSet $SYSPROF 'NetworkThrottlingIndex' -1; RSet $SYSPROF 'SystemResponsiveness' 0 } `
    { RSet $SYSPROF 'NetworkThrottlingIndex' 10; RSet $SYSPROF 'SystemResponsiveness' 20 }

  Tw 'reseau' 'DNS rapide (Cloudflare)' 'Fait passer ton PC par le DNS public 1.1.1.1, plus rapide que celui de ta box.' 'Annulable : remet le DNS automatique de ta box.' $false `
    { $a = Get-NetAdapter -Physical -ErrorAction SilentlyContinue | Where-Object Status -eq 'Up' | Select-Object -First 1; if (-not $a) { return $false }; $d = (Get-DnsClientServerAddress -InterfaceIndex $a.ifIndex -AddressFamily IPv4 -ErrorAction SilentlyContinue).ServerAddresses; return [bool]($d -contains '1.1.1.1') } `
    { Get-NetAdapter -Physical -ErrorAction SilentlyContinue | Where-Object Status -eq 'Up' | ForEach-Object { Set-DnsClientServerAddress -InterfaceIndex $_.ifIndex -ServerAddresses ('1.1.1.1','1.0.0.1') } } `
    { Get-NetAdapter -Physical -ErrorAction SilentlyContinue | Where-Object Status -eq 'Up' | ForEach-Object { Set-DnsClientServerAddress -InterfaceIndex $_.ifIndex -ResetServerAddresses } }

  Tw 'reseau' 'Désactiver le partage P2P des mises à jour' 'Empêche Windows d''utiliser ta connexion pour distribuer ses mises à jour à d''autres PC.' 'Libère de la bande passante montante et réduit les pics de latence.' $true `
    { (RGet "$POL\DeliveryOptimization" 'DODownloadMode') -eq 0 } `
    { RSet "$POL\DeliveryOptimization" 'DODownloadMode' 0 } `
    { RDel "$POL\DeliveryOptimization" 'DODownloadMode' }

  Tw 'reseau' 'Désactiver SMBv1 (sécurité)' 'Coupe l''ancien protocole de partage de fichiers SMBv1, utilisé par plusieurs ransomwares.' 'Sans effet sur l''usage normal, sauf très vieux matériel réseau.' $true `
    { (Get-SmbServerConfiguration -ErrorAction SilentlyContinue).EnableSMB1Protocol -eq $false } `
    { Set-SmbServerConfiguration -EnableSMB1Protocol $false -Force -Confirm:$false } `
    { Set-SmbServerConfiguration -EnableSMB1Protocol $true -Force -Confirm:$false }

  Tw 'reseau' 'Libérer la bande passante réservée' 'Supprime la limite de 20 % que Windows peut réserver pour ses propres usages (QoS).' 'Toute ta connexion est disponible pour tes applis et jeux.' $true `
    { (RGet "$POL\Psched" 'NonBestEffortLimit') -eq 0 } `
    { RSet "$POL\Psched" 'NonBestEffortLimit' 0 } `
    { RDel "$POL\Psched" 'NonBestEffortLimit' }

  Tw 'reseau' 'Désactiver IPv6' 'Désactive le protocole IPv6 sur toutes les cartes réseau.' 'Réservé aux cas de problèmes de connexion. Redémarrage nécessaire.' $false `
    { (RGet 'HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip6\Parameters' 'DisabledComponents') -eq 255 } `
    { RSet 'HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip6\Parameters' 'DisabledComponents' 255 } `
    { RDel 'HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip6\Parameters' 'DisabledComponents' }

  TwAction 'reseau' 'Vider le cache DNS' 'Efface la mémoire des adresses de sites visités.' 'Utile quand un site refuse de s''ouvrir alors qu''internet fonctionne.' 'Vider' $false {
    Clear-DnsClientCache; Dire "✓ Cache DNS vidé" }

  TwAction 'reseau' 'Réinitialiser le réseau' 'Remet à zéro Winsock et la pile IP de Windows.' 'À utiliser en cas de problème de connexion persistant. Redémarrage nécessaire.' 'Réinitialiser' $false {
    if ([System.Windows.MessageBox]::Show("Réinitialiser Winsock et la pile IP ? Un redémarrage sera nécessaire.", "BxB", 'YesNo', 'Question') -eq 'Yes') {
      netsh winsock reset | Out-Null; netsh int ip reset | Out-Null
      Dire "✓ Réseau réinitialisé : redémarre le PC pour finir" } }

  # ---------------- PERFORMANCES ----------------
  Tw 'perf' 'Désactiver l''hibernation' 'Supprime le mode hibernation (utile surtout sur un PC fixe).' 'Libère de l''espace disque. À éviter sur un portable.' $false `
    { (RGet 'HKLM:\SYSTEM\CurrentControlSet\Control\Power' 'HibernateEnabled') -eq 0 } `
    { powercfg /h off } `
    { powercfg /h on }

  Tw 'perf' 'Désactiver les apps en arrière-plan' 'Empêche les applications Microsoft Store de tourner en arrière-plan.' 'Libère de la RAM et réduit l''utilisation CPU au repos.' $true `
    { (RGet 'HKCU:\Software\Microsoft\Windows\CurrentVersion\BackgroundAccessApplications' 'GlobalUserDisabled') -eq 1 } `
    { RSet 'HKCU:\Software\Microsoft\Windows\CurrentVersion\BackgroundAccessApplications' 'GlobalUserDisabled' 1; RSet 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Search' 'BackgroundAppGlobalToggle' 0 } `
    { RSet 'HKCU:\Software\Microsoft\Windows\CurrentVersion\BackgroundAccessApplications' 'GlobalUserDisabled' 0; RSet 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Search' 'BackgroundAppGlobalToggle' 1 }

  Tw 'perf' 'Plan d''alimentation Performances élevées' 'Active un mode performance maximale pour le PC.' 'Évite toute baisse automatique de performances.' $true `
    { [bool]((powercfg /getactivescheme) -match '8c5e7fda') } `
    { powercfg /setactive SCHEME_MIN } `
    { powercfg /setactive SCHEME_BALANCED }

  TwAction 'perf' 'Programmes au démarrage' 'Affiche tous les programmes qui se lancent automatiquement au démarrage.' 'Désactive ceux dont tu n''as pas besoin pour libérer des ressources.' 'Ouvrir' $true {
    Start-Process 'ms-settings:startupapps' }

  Tw 'jeux' 'Mode Jeu Windows' 'Active le mode jeu : Windows donne la priorité au jeu en cours.' 'Limite les tâches de fond pendant tes parties.' $true `
    { (RGet 'HKCU:\Software\Microsoft\GameBar' 'AutoGameModeEnabled') -eq 1 } `
    { RSet 'HKCU:\Software\Microsoft\GameBar' 'AutoGameModeEnabled' 1 } `
    { RSet 'HKCU:\Software\Microsoft\GameBar' 'AutoGameModeEnabled' 0 }

  Tw 'jeux' 'Désactiver Xbox Game Bar' 'Désactive l''overlay Xbox Game Bar et la capture DVR.' 'Supprime un overlay actif en jeu sans toucher à l''app Xbox.' $true `
    { (RGet 'HKCU:\System\GameConfigStore' 'GameDVR_Enabled') -eq 0 } `
    { RSet 'HKCU:\System\GameConfigStore' 'GameDVR_Enabled' 0; RSet 'HKCU:\Software\Microsoft\Windows\CurrentVersion\GameDVR' 'AppCaptureEnabled' 0; RSet 'HKCU:\Software\Microsoft\GameBar' 'UseNexusForGameBarEnabled' 0 } `
    { RSet 'HKCU:\System\GameConfigStore' 'GameDVR_Enabled' 1; RSet 'HKCU:\Software\Microsoft\Windows\CurrentVersion\GameDVR' 'AppCaptureEnabled' 1; RSet 'HKCU:\Software\Microsoft\GameBar' 'UseNexusForGameBarEnabled' 1 }

  Tw 'perf' 'Désactiver SysMain (Superfetch)' 'Désactive le service SysMain de Windows.' 'Réduit les lectures disque en arrière-plan, surtout sur SSD. À éviter sur disque dur.' $false `
    { (Get-Service SysMain -ErrorAction SilentlyContinue).StartType -eq 'Disabled' } `
    { Stop-Service SysMain -Force -ErrorAction SilentlyContinue; Set-Service SysMain -StartupType Disabled } `
    { Set-Service SysMain -StartupType Automatic; Start-Service SysMain -ErrorAction SilentlyContinue }

  Tw 'perf' 'Désactiver le démarrage rapide' 'Désactive le « démarrage rapide » de Windows (arrêt hybride).' 'Corrige certains bugs après arrêt et garantit un vrai redémarrage à froid.' $false `
    { (RGet 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Power' 'HiberbootEnabled') -eq 0 } `
    { RSet 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Power' 'HiberbootEnabled' 0 } `
    { RSet 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Power' 'HiberbootEnabled' 1 }

  Tw 'perf' 'Priorité aux programmes actifs' 'Donne plus de temps processeur à la fenêtre que tu utilises.' 'Améliore la réactivité des applis au premier plan.' $true `
    { (RGet 'HKLM:\SYSTEM\CurrentControlSet\Control\PriorityControl' 'Win32PrioritySeparation') -eq 38 } `
    { RSet 'HKLM:\SYSTEM\CurrentControlSet\Control\PriorityControl' 'Win32PrioritySeparation' 38 } `
    { RSet 'HKLM:\SYSTEM\CurrentControlSet\Control\PriorityControl' 'Win32PrioritySeparation' 2 }

  Tw 'perf' 'Désactiver la veille des ports USB' 'Empêche Windows de couper l''alimentation des périphériques USB.' 'Évite les micro-déconnexions de la souris, du clavier et de la manette.' $true `
    { (RGet 'HKLM:\SYSTEM\CurrentControlSet\Services\USB' 'DisableSelectiveSuspend') -eq 1 } `
    { RSet 'HKLM:\SYSTEM\CurrentControlSet\Services\USB' 'DisableSelectiveSuspend' 1 } `
    { RSet 'HKLM:\SYSTEM\CurrentControlSet\Services\USB' 'DisableSelectiveSuspend' 0 }

  Tw 'perf' 'Arrêt plus rapide du PC' 'Réduit le délai d''attente avant que Windows ferme les services et programmes bloqués.' 'Le PC s''éteint plus vite quand un programme ne répond pas.' $true `
    { (RGet 'HKLM:\SYSTEM\CurrentControlSet\Control' 'WaitToKillServiceTimeout') -eq '2000' } `
    { RSet 'HKLM:\SYSTEM\CurrentControlSet\Control' 'WaitToKillServiceTimeout' '2000' 'String'; RSet 'HKCU:\Control Panel\Desktop' 'HungAppTimeout' '2000' 'String'; RSet 'HKCU:\Control Panel\Desktop' 'WaitToKillAppTimeout' '2000' 'String' } `
    { RSet 'HKLM:\SYSTEM\CurrentControlSet\Control' 'WaitToKillServiceTimeout' '5000' 'String'; RSet 'HKCU:\Control Panel\Desktop' 'HungAppTimeout' '5000' 'String'; RSet 'HKCU:\Control Panel\Desktop' 'WaitToKillAppTimeout' '20000' 'String' }

  Tw 'perf' 'Menus instantanés' 'Supprime le petit délai d''ouverture des menus.' 'Interface plus vive. Visible après reconnexion.' $true `
    { (RGet 'HKCU:\Control Panel\Desktop' 'MenuShowDelay') -eq '0' } `
    { RSet 'HKCU:\Control Panel\Desktop' 'MenuShowDelay' '0' 'String' } `
    { RSet 'HKCU:\Control Panel\Desktop' 'MenuShowDelay' '400' 'String' }

  TwAction 'perf' 'Nettoyage de disque Windows' 'Ouvre l''outil officiel de nettoyage de Windows.' 'Pour supprimer les anciens fichiers système et les restes de mises à jour.' 'Ouvrir' $false {
    Start-Process cleanmgr }

  Tw 'jeux' 'Planification GPU accélérée (HAGS)' 'Laisse la carte graphique gérer sa propre mémoire vidéo.' 'Peut réduire la latence selon ta carte. Redémarrage nécessaire.' $false `
    { (RGet 'HKLM:\SYSTEM\CurrentControlSet\Control\GraphicsDrivers' 'HwSchMode') -eq 2 } `
    { RSet 'HKLM:\SYSTEM\CurrentControlSet\Control\GraphicsDrivers' 'HwSchMode' 2 } `
    { RSet 'HKLM:\SYSTEM\CurrentControlSet\Control\GraphicsDrivers' 'HwSchMode' 1 }

  Tw 'jeux' 'Priorité GPU et CPU pour les jeux' 'Donne la priorité maximale aux jeux dans le planificateur multimédia de Windows.' 'Plus de ressources pour tes parties, moins aux tâches de fond.' $true `
    { (RGet "$SYSPROF\Tasks\Games" 'Priority') -eq 6 } `
    { RSet "$SYSPROF\Tasks\Games" 'GPU Priority' 8; RSet "$SYSPROF\Tasks\Games" 'Priority' 6; RSet "$SYSPROF\Tasks\Games" 'Scheduling Category' 'High' 'String'; RSet "$SYSPROF\Tasks\Games" 'SFIO Priority' 'High' 'String' } `
    { RSet "$SYSPROF\Tasks\Games" 'GPU Priority' 8; RSet "$SYSPROF\Tasks\Games" 'Priority' 2; RSet "$SYSPROF\Tasks\Games" 'Scheduling Category' 'Medium' 'String'; RSet "$SYSPROF\Tasks\Games" 'SFIO Priority' 'Normal' 'String' }

  Tw 'jeux' 'Désactiver les optimisations plein écran' 'Force le vrai mode plein écran pour les jeux au lieu du mode fenêtré optimisé.' 'Peut réduire l''input lag dans certains jeux.' $true `
    { (RGet 'HKCU:\System\GameConfigStore' 'GameDVR_FSEBehaviorMode') -eq 2 } `
    { RSet 'HKCU:\System\GameConfigStore' 'GameDVR_FSEBehaviorMode' 2; RSet 'HKCU:\System\GameConfigStore' 'GameDVR_HonorUserFSEBehaviorMode' 1; RSet 'HKCU:\System\GameConfigStore' 'GameDVR_FSEBehavior' 2; RSet 'HKCU:\System\GameConfigStore' 'GameDVR_DXGIHonorFSEWindowsCompatible' 1 } `
    { RSet 'HKCU:\System\GameConfigStore' 'GameDVR_FSEBehaviorMode' 0; RSet 'HKCU:\System\GameConfigStore' 'GameDVR_HonorUserFSEBehaviorMode' 0; RSet 'HKCU:\System\GameConfigStore' 'GameDVR_FSEBehavior' 0; RSet 'HKCU:\System\GameConfigStore' 'GameDVR_DXGIHonorFSEWindowsCompatible' 0 }

  Tw 'jeux' 'Couper les notifications Windows' 'Désactive les pop-ups de notifications pendant que tu joues.' 'Plus aucune interruption en pleine partie.' $false `
    { (RGet 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Notifications\Settings' 'NOC_GLOBAL_SETTING_TOASTS_ENABLED') -eq 0 } `
    { RSet 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Notifications\Settings' 'NOC_GLOBAL_SETTING_TOASTS_ENABLED' 0 } `
    { RSet 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Notifications\Settings' 'NOC_GLOBAL_SETTING_TOASTS_ENABLED' 1 }

  TwAction 'jeux' 'Paramètres graphiques Windows' 'Ouvre les réglages graphiques avancés de Windows.' 'Choisis la carte graphique utilisée par chaque jeu.' 'Ouvrir' $false {
    Start-Process 'ms-settings:display-advancedgraphics' }


  # =================================================================
  # OPTIMISATIONS : logique des cartes
  # =================================================================
  function Dire($t) { $Toast.Text = $t }
  function Rafraichir { $window.Dispatcher.Invoke([Action]{}, [System.Windows.Threading.DispatcherPriority]::Render) }

  function PointRestaurationUnique {
    if ($script:restaureUI) { return }
    $script:restaureUI = $true
    Dire "Création d'un point de restauration (quelques secondes)..."
    Rafraichir
    Enable-ComputerRestore -Drive "C:\" -ErrorAction SilentlyContinue
    Checkpoint-Computer -Description "Avant optimisations BxB" -RestorePointType MODIFY_SETTINGS -ErrorAction SilentlyContinue
  }

  function Appliquer($t, $actif) {
    PointRestaurationUnique
    $window.Cursor = [System.Windows.Input.Cursors]::Wait
    try { if ($actif) { & $t.On | Out-Null } else { & $t.Off | Out-Null } } catch {}
    try { $t.Etat = [bool](& $t.Test) } catch { $t.Etat = $false }
    $window.Cursor = $null
    return ($t.Etat -eq $actif)
  }

  function Basculer($tg) {
    $t = $tg.Tag
    $veut = [bool]$tg.IsChecked
    $ok = Appliquer $t $veut
    $tg.IsChecked = $t.Etat
    if ($ok) {
      $mot = 'désactivé'; if ($veut) { $mot = 'activé' }
      Dire "✓ $($t.Titre) : $mot"
    } else {
      Dire "✗ Impossible de modifier « $($t.Titre) » (protégé par Windows ?)"
    }
  }

  # Création des cartes + lecture de l'état réel
  $styleSwitch = $window.FindResource('Switch')
  $styleBtn = $window.FindResource('Btn')
  foreach ($t in $tweaks) {
    $c = [Windows.Markup.XamlReader]::Parse($carteXaml)
    $c.FindName('CTitre').Text = $t.Titre
    $c.FindName('CD1').Text = $t.D1
    $c.FindName('CD2').Text = $t.D2
    if ($t.Reco) { $c.FindName('CReco').Visibility = 'Visible' }
    $tg = $c.FindName('CTog')
    $bt = $c.FindName('CBtn')
    $tg.Style = $styleSwitch
    $bt.Style = $styleBtn
    if ($t.Action) {
      $tg.Visibility = 'Collapsed'
      $bt.Visibility = 'Visible'
      $bt.Content = $t.Bouton
      $bt.Tag = $t
      $bt.Add_Click({ & $args[0].Tag.Action })
    } else {
      try { $t.Etat = [bool](& $t.Test) } catch { $t.Etat = $false }
      $tg.IsChecked = $t.Etat
      $tg.Tag = $t
      $tg.Add_Click({ Basculer $args[0] })
    }
    $t.Carte = $c
    $t.Tg = $tg
  }

  function AfficherOnglet($nom) {
    $Cartes.Children.Clear()
    foreach ($t in $tweaks) {
      if ($t.Tab -eq $nom) {
        if (-not $t.Action) { $t.Tg.IsChecked = $t.Etat }
        [void]$Cartes.Children.Add($t.Carte)
      }
    }
    $Scroll.ScrollToTop()
  }

  $tabs = @($TabPriv, $TabConfort, $TabReseau, $TabPerf, $TabJeux)
  function OngletCourant { return (($tabs | Where-Object { $_.IsChecked }) | Select-Object -First 1).Tag }
  foreach ($tab in $tabs) { $tab.Add_Checked({ AfficherOnglet $args[0].Tag }) }
  AfficherOnglet 'priv'

  $BtnBoost.Add_Click({
    $reponse = [System.Windows.MessageBox]::Show("BOOST va activer tous les réglages recommandés (marqués ⚡) dans tous les onglets.`n`nUn point de restauration est créé avant, et tout peut être annulé avec « Tout restaurer ».`n`nContinuer ?", "BOOST", 'YesNo', 'Question')
    if ($reponse -ne 'Yes') { return }
    $n = 0
    foreach ($t in $tweaks) {
      if ($t.Reco -and -not $t.Action -and -not $t.Etat) {
        # on évite de redémarrer l'Explorateur pendant un BOOST : aucun réglage recommandé ne le fait
        if (Appliquer $t $true) { $n++ }
      }
    }
    AfficherOnglet (OngletCourant)
    Dire "⚡ BOOST terminé : $n réglage(s) appliqué(s). Redémarre le PC pour tout finaliser."
  })

  $BtnRestore.Add_Click({
    $reponse = [System.Windows.MessageBox]::Show("Remettre TOUS les réglages de la page Optimisations aux valeurs par défaut de Windows ?", "Tout restaurer", 'YesNo', 'Question')
    if ($reponse -ne 'Yes') { return }
    $n = 0
    foreach ($t in $tweaks) {
      if (-not $t.Action -and $t.Etat) {
        if (Appliquer $t $false) { $n++ }
      }
    }
    AfficherOnglet (OngletCourant)
    Dire "↩ $n réglage(s) remis par défaut."
  })

  # =================================================================
  # DASHBOARD : lancement des tâches en arrière-plan
  # =================================================================
  function Ajouter($type, $texte) {
    $haut = 0; if ($type -eq 'titre') { $haut = 10 }
    $p = New-Object System.Windows.Documents.Paragraph
    $p.Margin = New-Object System.Windows.Thickness -ArgumentList 0, $haut, 0, 0
    $r = New-Object System.Windows.Documents.Run $texte
    $r.Foreground = $conv.ConvertFromString($couleurs[$type])
    if ($type -eq 'titre' -or $type -eq 'fin') { $r.FontWeight = [System.Windows.FontWeights]::Bold }
    $p.Inlines.Add($r)
    $Log.Document.Blocks.Add($p)
    $Log.ScrollToEnd()
  }

  function Lancer($mode) {
    if ($sync.Occupe) { return }
    $sync.Occupe = $true
    $sync.Fini = $false
    $sync.Progress = 0
    $sync.Statut = "Démarrage..."
    $sync.Question = $null
    foreach ($b in $boutons) { $b.IsEnabled = $false }
    $BtnRapport.Visibility = 'Collapsed'
    $Log.Document.Blocks.Clear()
    $Prog.Value = 0

    $rs = [runspacefactory]::CreateRunspace()
    $rs.ApartmentState = 'MTA'
    $rs.Open()
    $rs.SessionStateProxy.SetVariable('sync', $sync)
    $script:ps = [powershell]::Create()
    $script:ps.Runspace = $rs
    $null = $script:ps.AddScript($Work.ToString()).AddArgument($mode)
    $script:handle = $script:ps.BeginInvoke()
  }

  $BtnVerif.Add_Click({ Lancer 'verif' })
  $BtnMaj.Add_Click({ Lancer 'maj' })
  $BtnOpti.Add_Click({ Lancer 'opti' })
  $BtnAll.Add_Click({ Lancer 'tout' })
  $BtnRapport.Add_Click({ if ($script:cheminRapport) { Start-Process notepad.exe $script:cheminRapport } })
  $BtnMin.Add_Click({ $window.WindowState = 'Minimized' })
  $BtnClose.Add_Click({ $window.Close() })
  $TitleBar.Add_MouseLeftButtonDown({ $window.DragMove() })
  $BtnOui.Add_Click({ $sync.Answer = $true;  $Overlay.Visibility = 'Collapsed'; $sync.Event.Set() | Out-Null })
  $BtnNon.Add_Click({ $sync.Answer = $false; $Overlay.Visibility = 'Collapsed'; $sync.Event.Set() | Out-Null })

  # Menu de gauche : changement de page
  $NavDash.Add_Checked({ $PageDash.Visibility = 'Visible'; $PageOpti.Visibility = 'Collapsed' })
  $NavOpti.Add_Checked({ $PageDash.Visibility = 'Collapsed'; $PageOpti.Visibility = 'Visible' })

  # Boucle d'affichage : vide la file de messages du thread de travail
  $timer = New-Object System.Windows.Threading.DispatcherTimer
  $timer.Interval = [TimeSpan]::FromMilliseconds(100)
  $timer.Add_Tick({
    $item = $null
    while ($sync.Queue.TryDequeue([ref]$item)) {
      if ($item.T -eq 'rapport') {
        $script:cheminRapport = $item.X
        $BtnRapport.Visibility = 'Visible'
      } else {
        Ajouter $item.T $item.X
      }
    }
    $Prog.Value = [double]$sync.Progress
    if ($sync.Statut) { $Statut.Text = $sync.Statut }

    $q = $sync.Question
    if ($q) {
      $sync.Question = $null
      $QTexte.Text = $q.Texte
      $QDetail.Text = $q.Detail
      $QDetail.Visibility = $(if ($q.Detail) { 'Visible' } else { 'Collapsed' })
      $Overlay.Visibility = 'Visible'
    }

    if ($sync.Occupe -and $sync.Fini -and $sync.Queue.IsEmpty) {
      $sync.Occupe = $false
      foreach ($b in $boutons) { $b.IsEnabled = $true }
      try { $script:ps.EndInvoke($script:handle) } catch {}
      $script:ps.Runspace.Close()
      $script:ps.Dispose()
    }
  })
  $timer.Start()

  Ajouter 'titre' "Bienvenue !"
  Ajouter 'info' "Choisis une action ci-dessus, ou clique sur TOUT FAIRE."
  Ajouter 'ligne' "Va dans OPTIMISATIONS (menu de gauche) pour régler Windows avec des interrupteurs."
  Ajouter 'ligne' "Un point de restauration est créé avant toute modification. Le BIOS n'est jamais modifié."

  $window.ShowDialog() | Out-Null
}
catch {
  [System.Windows.MessageBox]::Show("Erreur : $($_.Exception.Message)", "BxB") | Out-Null
}
