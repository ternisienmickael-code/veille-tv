@echo off
rem Double-clique pour fabriquer BxB.exe (aucun telechargement necessaire).
rem Garde dans le meme dossier : BxB.ps1, BxB_Launcher.cs, BxB.manifest, BxB.ico
cd /d "%~dp0"

set CSC=%windir%\Microsoft.NET\Framework64\v4.0.30319\csc.exe
if not exist "%CSC%" set CSC=%windir%\Microsoft.NET\Framework\v4.0.30319\csc.exe
if not exist "%CSC%" (
  echo Le compilateur de Windows est introuvable.
  pause
  exit /b 1
)
if not exist BxB.ico (
  echo BxB.ico est introuvable dans ce dossier.
  pause
  exit /b 1
)
if not exist BxB.ps1 (
  echo BxB.ps1 est introuvable dans ce dossier.
  pause
  exit /b 1
)
if exist BxB.exe del BxB.exe

"%CSC%" /nologo /target:winexe /out:BxB.exe /win32manifest:BxB.manifest /win32icon:BxB.ico /reference:System.Windows.Forms.dll /resource:BxB.ps1,BxB.ps1 BxB_Launcher.cs

if exist BxB.exe (
  echo.
  echo BxB.exe est pret dans ce dossier !
) else (
  echo.
  echo La creation a echoue. Envoie-moi le message ci-dessus.
)
echo.
pause
