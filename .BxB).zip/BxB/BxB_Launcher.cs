using System;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Windows.Forms;

static class BxBLauncher
{
    [STAThread]
    static void Main()
    {
        try
        {
            // Le script BxB.ps1 est integre dans l'exe : on l'extrait puis on le lance sans fenetre noire
            string dossier = Path.Combine(Path.GetTempPath(), "BxB");
            Directory.CreateDirectory(dossier);
            string ps1 = Path.Combine(dossier, "BxB.ps1");

            using (Stream source = Assembly.GetExecutingAssembly().GetManifestResourceStream("BxB.ps1"))
            using (FileStream cible = File.Create(ps1))
            {
                source.CopyTo(cible);
            }

            ProcessStartInfo psi = new ProcessStartInfo("powershell.exe",
                "-NoProfile -ExecutionPolicy Bypass -STA -WindowStyle Hidden -File \"" + ps1 + "\"");
            psi.UseShellExecute = false;
            psi.CreateNoWindow = true;
            Process.Start(psi);
        }
        catch (Exception e)
        {
            MessageBox.Show("Impossible de lancer BxB : " + e.Message, "BxB");
        }
    }
}
